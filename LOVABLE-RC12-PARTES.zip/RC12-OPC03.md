# PROMPT LOVABLE — RC12 · PARTE OPCIONAL 3 de 3 — Harness pgTAP local falha em PostgreSQL 16 e anula os… · Buckets de storage usados pelo código sem criação em… · .env.example sem as variáveis lidas pelas funções edge [LOW]

**Regras (as mesmas da Parte 1, em resumo):** aplique só o que está nesta parte; os diffs são `-U2` com números de linha do ficheiro ORIGINAL e, se um não aplicar, pare nessa secção e diga qual; "Criar" = ficheiro novo com o conteúdo exato; as migrações SQL são idempotentes, correm numa transação e os blocos `DO $guard$` abortam de propósito se a função real divergiu (devolva o `md5` e o `pg_get_functiondef`, nunca desative o guarda); não edite migrações existentes nem `types.ts`; publique as edge functions alteradas; no fim responda com as secções aplicadas, as não aplicadas (com razão) e qualquer erro, com o texto exato.

---

## Buckets de storage usados pelo código sem criação em migração (ids: SCH-16)
**Gravidade:** LOW. **Quem é afetado:** todos os papéis (avatares, logos, documentos do workspace, capturas de bugs) numa base nova ou restaurada de migrações; admin (census-run, exportação do modelo financeiro).
**Problema:** `workspace-documents`, `bug-report-screenshots`, `profile-avatars`, `startup-logos`, `template_assets`, `phc-extracts` e `admin-exports` têm políticas em migrações mas nenhum `INSERT INTO storage.buckets` (a migração `20260715125639`, do bucket de capturas de bugs, até diz "bucket is created via tool"). Numa base nova o upload dá "Bucket not found" e o `census-run` falha em `exception_upload_failed` (`supabase/functions/census-run/index.ts:200,349`).
**Correção:** migração nova que cria os sete buckets com `INSERT ... ON CONFLICT (id) DO NOTHING`: em produção, onde já existem, não altera nada (nem `public`, nem limites, nem tipos MIME). Flags `public`: `profile-avatars` e `startup-logos` = `true`, porque o cliente guarda `getPublicUrl()` (`src/pages/Settings.tsx:128-130`, `src/components/workspace/StartupSettingsTab.tsx:183-185`) e a migração `20260415224512` os trata como buckets públicos (retira só a listagem anónima); os outros cinco = `false` (leitura por URL assinada ou service role, e políticas só para autenticados, staff ou admin). Não consegui ler a base de produção, por isso estas flags vêm da leitura do código e das políticas: confirme com a consulta abaixo antes de aplicar numa base nova. Validada na réplica viva: `storage.buckets` de 9 para 16 linhas, 2.ª aplicação sem erro nem alteração, e um bucket preexistente com `public=true` mantém-se.
**Criar `supabase/migrations/20261103400000_rc12_storage_buckets.sql`** (conteúdo exato):

```sql
-- RC12 / SCH-16: buckets de storage usados pelo código que só existiam por políticas
-- (nenhuma migração os criava). Numa base nova ou restaurada de migrações o upload dava
-- 'Bucket not found' e o census-run falhava em exception_upload_failed.
--
-- Idempotente e sem efeito em produção: ON CONFLICT (id) DO NOTHING não altera nenhum bucket
-- que já exista (flag public, limites e tipos MIME ficam como estão).
--
-- Flags `public`:
--   * profile-avatars, startup-logos -> true: o cliente guarda `getPublicUrl()`
--     (src/pages/Settings.tsx:128-130, src/components/workspace/StartupSettingsTab.tsx:183-185)
--     e a migração 20260415224512 trata-os como 'public bucket' (remove só a listagem anónima).
--   * workspace-documents, bug-report-screenshots, template_assets, phc-extracts, admin-exports
--     -> false: leitura por URL assinada ou por service_role (useDocuments.ts:238 createSignedUrl,
--     export-financial-model, census-run) e políticas de leitura só para utilizadores autenticados/staff/admin.
INSERT INTO storage.buckets (id, name, public) VALUES
  ('workspace-documents',    'workspace-documents',    false),
  ('bug-report-screenshots', 'bug-report-screenshots', false),
  ('template_assets',        'template_assets',        false),
  ('phc-extracts',           'phc-extracts',           false),
  ('admin-exports',          'admin-exports',          false),
  ('profile-avatars',        'profile-avatars',        true),
  ('startup-logos',          'startup-logos',          true)
ON CONFLICT (id) DO NOTHING;
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## Teste de privilégios não cobria purge_operational_logs (ids: DBP-07, OPS-12, parte de testes)
**Gravidade:** LOW. **Quem é afetado:** quem mantém a base (regressão de segurança: função `SECURITY DEFINER` que apaga registos).
**Problema:** a migração `20261103203000_rc12_log_retention.sql` cria `public.purge_operational_logs()` (só `service_role`), mas `supabase/tests/service_only_function_privileges.test.sql` não a inclui na lista de funções que `anon` e `authenticated` não podem executar, por isso uma futura regressão nos privilégios passava despercebida.
**Correção:** acrescentar `'public.purge_operational_logs()'` ao fim da lista (a vírgula passa para a linha anterior). Corrido na réplica viva com as migrações rc12 aplicadas e pgTAP carregado, tudo em `BEGIN`/`ROLLBACK`: `ok 1 - internal SECURITY DEFINER functions are not executable by anon or authenticated`. Com um `GRANT EXECUTE ON FUNCTION public.purge_operational_logs() TO authenticated` antes do teste, o teste falha como deve (`not ok 1 ... ("public.purge_operational_logs()",f,t)`). O teste só é significativo com os privilégios por omissão do Supabase emulados (a réplica tem-nos), como diz o cabeçalho do ficheiro.
**Alterar `supabase/tests/service_only_function_privileges.test.sql`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/tests/service_only_function_privileges.test.sql
+++ b/supabase/tests/service_only_function_privileges.test.sql
@@ -45,5 +45,6 @@ SELECT is_empty($q$
     'public.cron_invoke_edge(text,jsonb)',
     'public.cron_invoke_rpc(text,text)',
-    'public.touch_public_booking_rate_limit(text,text)'
+    'public.touch_public_booking_rate_limit(text,text)',
+    'public.purge_operational_logs()'
     ]::text[]) AS s
    WHERE has_function_privilege('anon', s::regprocedure, 'EXECUTE')
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## .env.example sem as variáveis lidas pelas funções edge (ids: OPS-14, parte .env.example)
**Gravidade:** LOW. **Quem é afetado:** admin e equipa técnica (quem configura um ambiente novo).
**Problema:** `.env.example` não menciona 14 nomes de variáveis que as funções edge leem (`grep -rhoE "Deno\.env\.get\(...\)" supabase/functions`): `PUBLIC_APP_URL` e `SITE_URL` (que, com `APP_URL`, formam três nomes para o mesmo URL público; configurar só um deixa links de email com o domínio por omissão), `ALLOWED_ORIGINS`, `MS_GRAPH_SHAREPOINT_DRIVE_ID`, `DOCUSIGN_INTEGRATION_KEY`, `DOCUSIGN_USER_ID`, `DOCUSIGN_ACCOUNT_ID`, `DOCUSIGN_BASE_URL`, `DOCUSIGN_RSA_PRIVATE_KEY`, `TWILIO_API_KEY`, `TWILIO_PHONE_NUMBER`, `STRIPE_SECRET_KEY`, `RECONCILER_WRITE_MODE` e `PUBLIC_BOOKING_ALLOW_DEMO`.
**Correção:** acrescentar ao fim do ficheiro um bloco de comentários, só com nomes e uma frase curta em PT-PT sobre cada um (sem valores reais; o ficheiro continua a passar `scripts/secret-scan.cjs`). Avisa que as três variáveis de URL têm de ter o MESMO valor e que `PUBLIC_BOOKING_ALLOW_DEMO` nunca se usa em produção. O resto do achado OPS-14 (documentos e script de reconciliação) está na secção do domínio de operações.
**Alterar `.env.example`** (diff; os números de linha são do ficheiro original):

```diff
--- a/.env.example
+++ b/.env.example
@@ -34,2 +34,28 @@ VITE_SUPABASE_PROJECT_ID=your-project-id
 # PANDADOC_WEBHOOK_KEY - Shared secret for PandaDoc webhook verification
 # WEBHOOK_SECRET is also used for DocuSign webhook verification
+
+# URL público da aplicação nos links dos emails (OPS-14). Use o MESMO valor nas três variáveis
+# (as funções edge leem nomes diferentes; configurar só uma deixa links com o domínio por omissão).
+# PUBLIC_APP_URL - lida pela maioria das funções (links em emails)
+# SITE_URL - lida por send-email-digest, send-announcement-email e automation-engine
+# (APP_URL, mais acima, completa as três)
+
+# Outras variáveis lidas por funções edge (todas opcionais, só nomes: valores em Lovable Cloud > Backend > Secrets):
+# ALLOWED_ORIGINS - lista CORS separada por vírgulas (opcional; há lista por omissão em _shared/cors.ts)
+# MS_GRAPH_SHAREPOINT_DRIVE_ID - identificador da drive do SharePoint onde se arquivam contratos
+
+# DocuSign (envio de contratos):
+# DOCUSIGN_INTEGRATION_KEY - chave de integração da app DocuSign
+# DOCUSIGN_USER_ID - utilizador API (GUID) em nome de quem se envia
+# DOCUSIGN_ACCOUNT_ID - identificador da conta DocuSign
+# DOCUSIGN_BASE_URL - URL base da API (por omissão o ambiente demo; em produção o da sua conta)
+# DOCUSIGN_RSA_PRIVATE_KEY - chave privada RSA do JWT; nunca a comite
+
+# WhatsApp (função dormente):
+# TWILIO_API_KEY - chave da API Twilio
+# TWILIO_PHONE_NUMBER - número remetente
+
+# Outras:
+# STRIPE_SECRET_KEY - import-kpi-data (opcional)
+# RECONCILER_WRITE_MODE - reconciler-run; a escrita só fica ativa com o valor "enabled" E o interruptor em system_settings ligado
+# PUBLIC_BOOKING_ALLOW_DEMO - NUNCA em produção (permite o token 'demo' nas páginas públicas de marcação)
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## Harness pgTAP local falha em PostgreSQL 16 e anula os REVOKE a anon (ids: DRF-03, OPS-07)
**Gravidade:** LOW. **Quem é afetado:** equipa técnica (harness local e CI `db-pgtap-local`).
**Problema:** A baseline `supabase/migrations/20260101120407_remix_migration_from_pg_dump.sql:20` tem `SET transaction_timeout = 0;`, parâmetro que só existe no PostgreSQL 17: em PG16 a transação aborta e as outras ~386 migrações falham em cascata. O harness (`scripts/rc5/local-pg-harness.sh:81`) só retira `CREATE EXTENSION`; as linhas 99-101 fazem `GRANT ALL ON ALL TABLES/SEQUENCES` a `anon` depois do replay, anulando os `REVOKE ... FROM anon` das migrações (`audit_five_blocking_reads` 6-10 falham sempre); e com `set -o pipefail` os `grep | head` das linhas 88 e 126 recebem SIGPIPE e o script termina com exit 141 a meio das suites. `supabase/config.toml` não fixa a versão do Postgres.
**Correção:** O harness remove a linha `SET transaction_timeout` no ficheiro depurado (a baseline não se edita), deixa de dar `GRANT ALL` a `anon` (os `ALTER DEFAULT PRIVILEGES` das linhas 71-73 já cobrem as tabelas criadas) e protege os dois `grep | head` com `|| true`. `supabase/config.toml` passa a declarar `[db] major_version = 17`, a versão da base alojada (o dump é 17.6), para o `supabase start` do CI não depender do valor por omissão do CLI (não testado sem o Supabase CLI). Validado: replay de todas as migrações em PG16.15 com 0 ficheiros em falha e 42 suites, `audit_five_blocking_reads` 10/10, exit 0 após a correção dos testes.
**Alterar `scripts/rc5/local-pg-harness.sh`** (diff; os números de linha são do ficheiro original):

```diff
--- a/scripts/rc5/local-pg-harness.sh
+++ b/scripts/rc5/local-pg-harness.sh
@@ -79,5 +79,6 @@ STRIP=$(mktemp -d)
 for f in "$ROOT"/supabase/migrations/*.sql; do
   # Managed extensions are provisioned by the platform, not by the harness.
-  perl -0pe 's/create\s+extension[^;]*;/-- [rc5 harness] extension stripped;/gis' "$f" > "$STRIP/$(basename "$f")"
+  # SET transaction_timeout only exists on PostgreSQL 17 (the baseline dump is 17.6); drop it so the replay also works on 16.
+  perl -0pe 's/create\s+extension[^;]*;/-- [rc5 harness] extension stripped;/gis; s/^SET transaction_timeout = 0;/-- [rc5 harness] PG17-only GUC stripped/gm' "$f" > "$STRIP/$(basename "$f")"
 done
 failed=0
@@ -86,5 +87,5 @@ for f in "$STRIP"/*.sql; do
     failed=$((failed+1))
     echo "[rc5:local-pg] replay FAIL $(basename "$f")"
-    echo "$out" | grep 'ERROR:' | head -2
+    { echo "$out" | grep 'ERROR:' | head -2; } || true
   fi
 done
@@ -97,7 +98,7 @@ fi
 # platform default privileges); RLS is the only boundary. Mirror that here or
 # privilege errors masquerade as policy passes.
-"${PSQL[@]}" -c 'GRANT USAGE ON SCHEMA public, extensions TO anon, authenticated, service_role;' \
-  -c 'GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated, service_role;' \
-  -c 'GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated, service_role;' >/dev/null
+# No blanket "GRANT ALL ON ALL TABLES" here: it would undo the REVOKE ... FROM anon of the migrations
+# (audit_five_blocking_reads); the ALTER DEFAULT PRIVILEGES above already cover every table the replay creates.
+"${PSQL[@]}" -c 'GRANT USAGE ON SCHEMA public, extensions TO anon, authenticated, service_role;' >/dev/null
 fi
 
@@ -124,5 +125,5 @@ for t in "${files[@]}"; do
   if [ "$psql_rc" != "0" ] || [ "$ok" = "0" ] || [ "$nok" != "0" ] || [ "$err" != "0" ]; then
     rc=1
-    printf '%s\n' "$out" | grep -E '^ not ok|# Failed test|caught:|wanted:|ERROR:' | head -12
+    { printf '%s\n' "$out" | grep -E '^ not ok|# Failed test|caught:|wanted:|ERROR:' | head -12; } || true
   fi
 done
```

**Alterar `supabase/config.toml`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/config.toml
+++ b/supabase/config.toml
@@ -1,4 +1,9 @@
 project_id = "apxzuslwhjujgrcsfzqw"
 
+# The baseline migration (20260101120407) was dumped from PostgreSQL 17.6 and starts with "SET transaction_timeout = 0;",
+# a parameter that only exists from PostgreSQL 17. Without this block `supabase start` uses the CLI default version.
+[db]
+major_version = 17
+
 # ============================================
 # USER-FACING FUNCTIONS (Category A)
```

---

## Documentos de operação desatualizados (ids: OPS-14)
**Gravidade:** LOW. **Quem é afetado:** admin e equipa técnica.
**Problema:** `docs/GO_LIVE_CHECKLIST.md` é de março (não fala de cron, segredos, cópias de segurança, interruptores de emergência nem das rondas RC10 a RC12); `docs/rc5/staging-runbook.md:46` manda correr `scripts/rc5/migrate-fresh.mjs`, que não existe (o ficheiro é `migrate-fresh-replay.mjs`, que não usa Docker nem `pg_prove`), e não diz que o staging chama as funções de produção a menos que `app.edge_base_url` esteja definido; `docs/rc5/release-checklist.md:19` repete o nome inexistente.
**Correção:** Nova lista de arranque e operação (20 minutos, 14 consultas SQL só de leitura, todas executadas sem erro numa base reconstruída das migrações da árvore final; verificação semanal; inventário de variáveis das funções edge; cópias de segurança; tabela "se algo falhar"), e correção dos dois runbooks. Fica de fora, por depender de migrações e de ficheiros de outros domínios: o novo manifesto de automações e o `reconcile-automations.mjs` (o confronto com `cron.job` da árvore final continua a dar desvios), o bloco novo de `.env.example` e a troca de `no-reply@` por `noreply@` em `supabase/functions/public-contract-onboarding/index.ts:420`.
