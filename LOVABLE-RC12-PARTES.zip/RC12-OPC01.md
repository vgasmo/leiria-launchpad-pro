# PROMPT LOVABLE — RC12 · PARTE OPCIONAL 1 de 3 — RLS: acesso por workspace avaliado por conjunto em vez… · Higiene de integridade: updated_at parado, FKs em… · commit-crm-import: sem reclamação do job, row_ids… [LOW]

## Regras (valem para esta parte)
1. Aplique TUDO o que está nesta parte e NADA mais. Não refatore, não renomeie, não "melhore" o que não é descrito.
2. Cada secção traz o diff exato (`diff -U2`, números de linha do ficheiro ORIGINAL, que é o que você tem agora). Se um diff não aplicar porque o ficheiro já mudou, **pare nessa secção e diga qual**; não improvise outra solução.
3. "Criar `caminho`" = ficheiro novo com o conteúdo exato. "Apagar" = remover o ficheiro.
4. Migrações SQL: crie-as em `supabase/migrations/` com o nome indicado, pela ordem dos nomes. Correm numa transação (sem `CONCURRENTLY`). São idempotentes. Várias começam por um bloco `DO $guard$` que **aborta de propósito** se a função real tiver divergido da definição de partida: se isso acontecer, **pare e devolva o `md5` e o resultado de `pg_get_functiondef` dessa função**; nunca desative o guarda nem reescreva a função por conta própria.
5. Nunca edite migrações que já existem, nem `src/integrations/supabase/types.ts` (é regenerado depois de cada migração).
6. Edge functions: depois de aplicar, publique as que foram alteradas e todas as que importam um `_shared/*` alterado.
7. Texto de UI: use as chaves `t('chave', 'texto PT')` dos diffs. As chaves novas estão no anexo `LOVABLE-RC12-I18N-PATCH.json` (aplicado uma vez, na Parte 1 do pacote essencial).
8. No fim, responda com: (a) a lista de secções aplicadas, (b) o que não aplicou e porquê, (c) qualquer erro de compilação ou de migração, com o texto exato.

**Edge functions alteradas nesta parte:** accept-mentor-nda, accept-workspace-invite, commit-crm-import, commit-hubspot-import, run-intake-reminders, staff-assign-workspace-to-contract.

---

## Gatilho de notificações a founders não acompanhou o RC11 D.9 (ids: FEF-11)
**Gravidade:** LOW. **Quem é afetado:** membros de workspace sem papel global founder/team_member.
**Problema:** O RC11 D.9 (`supabase/migrations/20261022110000_rc11_part_d.sql:45-58`) só corrigiu o helper `founder_notifications_blocked`; o gatilho `block_founder_notifications` continua a olhar só para `has_role`, pelo que um membro ativo sem papel global recebe notificações in-app com `notifications.founders_disabled = true`.
**Correção:** O gatilho passa a chamar `founder_notifications_blocked(NEW.user_id)` (mesma lógica, incluindo a isenção de staff e mentores). Guarda md5.
**Criar `supabase/migrations/20261103106000_rc12_founder_notifications_trigger.sql`** (conteúdo exato):

```sql
-- RC12 (sql_sec) · FEF-11 · block_founder_notifications passa a usar o mesmo critério de founder_notifications_blocked (RC11 D.9):
-- membros ativos de um workspace (founder/team_member) sem papel global também deixam de receber notificações in-app com o
-- interruptor notifications.founders_disabled ligado. Staff e mentores continuam isentos (a isenção está no helper).
-- Parte da definição VIVA (md5 ee55a0328c8307152cee258b300cb554); aborta se tiver divergido. Idempotente.
DO $guard$
DECLARE v_md5 text;
BEGIN
  SELECT md5(pg_get_functiondef(p.oid)) INTO v_md5 FROM pg_proc p
   WHERE p.pronamespace = 'public'::regnamespace AND p.proname = 'block_founder_notifications' AND pg_get_function_identity_arguments(p.oid) = '';
  IF v_md5 NOT IN ('ee55a0328c8307152cee258b300cb554', '3d565dcd55e46fd58c1beb634bc2e7e7') THEN
    RAISE EXCEPTION 'rc12: definição de public.block_founder_notifications divergente (md5 %), envie o resultado de pg_get_functiondef antes de aplicar', v_md5;
  END IF;
END $guard$;

CREATE OR REPLACE FUNCTION public.block_founder_notifications()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF public.founder_notifications_blocked(NEW.user_id) THEN
    RETURN NULL; -- descartar em silêncio
  END IF;
  RETURN NEW;
END;
$function$;
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## Teste pgTAP das proteções de dados (ids: E2E-05, ED3-05, SCH-03, FEF-11, FEB-01, FES-08)
**Gravidade:** LOW. **Quem é afetado:** equipa de desenvolvimento (regressões).
**Problema:** As correções acima precisam de cobertura automática.
**Correção:** Teste novo com 18 asserções (falham sem as migrações e passam com elas) para a reutilização da startup importada, o trigger do data room, a nota rápida do mentor, o gatilho de notificações e os CHECK de URL. Corre com `supabase test db`.

---

## RLS: acesso por workspace avaliado por conjunto em vez de uma função por linha (ids: DBP-04)
**Gravidade:** LOW (desempenho/escala, sem resultado errado). **Quem é afetado:** founder, team_member, consultor, backoffice, admin e mentor_externo.
**Problema:** `has_workspace_access`, `can_write_workspace`, `is_founder` e `is_conversation_participant` são `SQL STABLE SECURITY DEFINER` (não inlináveis) e as políticas (`supabase/migrations/20261019110000_rc11_part_b.sql:92` e outras) chamam-nas uma vez por linha: ~0,15 ms/linha para staff e 0,5 a 0,7 ms/linha para founder. Em `milestones` com 5 200 linhas um founder pagava 3,3 s só no RLS (em 100 mil linhas, 14 a 44 s por listagem); o backoffice demorava segundos a ver 0 linhas.
**Correção:** Migração que (1) acrescenta helpers de conjunto equivalentes, avaliados uma vez por consulta: `has_global_workspace_access()`, `has_global_write_access()` (exige conta aprovada também a admin/consultor, como o `can_write_workspace` atual), `member_workspace_ids()`, `writer_workspace_ids()`, `founder_workspace_ids()` e `my_conversation_ids()` (com `EXECUTE` para `anon` porque há políticas `TO public`, e devolvem vazio sem sessão); (2) reescreve, nas políticas de `action_items`, `milestones`, `sessions`, `documents`, `kpi_values`, `notifications`, `messages` e `conversation_participants`, `has_workspace_access(col)` para `(has_global_workspace_access() OR col IN (SELECT member_workspace_ids()))` e equivalentes, e `auth.uid()`/`is_admin()`/`has_role(...)` para `(SELECT ...)` (InitPlan). Medido na réplica com founder e 5 200 milestones: 3 314 ms para 3,8 ms; admin/consultor/backoffice ~2 ms. Equivalência verificada com 19 personas (incl. contas `pending`/suspensas, mentor com e sem NDA, workspace bloqueado, `anon`, `service_role`) em 20 tabelas: 380 comparações de leitura e 306 tentativas de escrita, 0 divergências. A migração lê `pg_policy` (por isso parte das políticas reais e as que não casarem ficam como estão), tem guarda de md5 sobre as 9 funções de que depende (aborta se divergirem) e a 2.ª aplicação não altera nada. Âmbito deliberadamente reduzido às 8 tabelas mais quentes: o `ALTER POLICY` pede `ACCESS EXCLUSIVE` nas tabelas durante a transação, por isso aplique fora das horas de ponta; depois de medir com `EXPLAIN (ANALYZE)` em produção pode alargar a lista `v_tables` (ver `workspace_users`, `communication_log`, `funnel_items`, `startup_contracts`).
**Criar `supabase/migrations/20261103202000_rc12_rls_set_helpers.sql`** (conteúdo exato):

```sql
-- RC12 (sql_db) · DBP-04 — RLS: avaliar o acesso por conjunto (1x por consulta) em vez de uma funcao SECURITY DEFINER por linha.
-- has_workspace_access / can_write_workspace / is_founder / is_conversation_participant sao SQL STABLE SECURITY DEFINER
-- (nao inlinaveis): o Postgres chama-as uma vez por linha (~0,15 a 0,7 ms/linha; em 20k linhas 3 a 9 s).
-- Esta migracao (a) acrescenta helpers de conjunto equivalentes e (b) reescreve, nas politicas das 8 tabelas mais quentes,
-- as chamadas por linha para `col IN (SELECT helper())` / `(SELECT fn())` (InitPlan). Comportamento identico:
-- equivalencia verificada para 19 personas x 20 tabelas (leitura e escrita), incluindo contas pending/suspensas,
-- mentor com e sem NDA, workspace bloqueado, anon e service_role.
-- Nota: o ALTER POLICY pede ACCESS EXCLUSIVE nas tabelas durante a transacao; aplicar fora das horas de ponta.
-- Idempotente: a 2.a aplicacao nao altera nenhuma politica.

-- Guarda: aborta (em vez de pisar) se as funcoes de que os helpers dependem divergirem da definicao de que partimos.
DO $guard$
DECLARE r record; v_expected jsonb := '{
  "can_write_workspace(_workspace_id uuid)": "2d4228fe6c8662cf41a45b5fa1031c9d",
  "has_workspace_access(_workspace_id uuid)": "5f79d5f43dde0df140e34aa1d7235cf3",
  "is_founder(_workspace_id uuid)": "bd39034be5befffbf413c5da16d3c750",
  "is_admin()": "34c2c6de8c80c4b013fb02c8d797bf5f",
  "is_account_active()": "ce406d5946bdd3a6e7c5a6875575cd6b",
  "is_account_active(_user_id uuid)": "a5d7a21723d2e213432adb8b229311c5",
  "account_not_suspended(_user_id uuid)": "323d060dd1ca1c4c0c7ccf01d637e46d",
  "is_conversation_participant(_user_id uuid, _conversation_id uuid)": "2392f9e8d0dcb27b9fead7d3bf0d7a19",
  "has_accepted_nda(_user_id uuid, _nda_version text)": "665aee8fd8adc952d56b56227c7e729f"
}'::jsonb;
BEGIN
  FOR r IN SELECT p.proname||'('||pg_get_function_identity_arguments(p.oid)||')' AS sig, md5(pg_get_functiondef(p.oid)) AS m
             FROM pg_proc p WHERE p.pronamespace='public'::regnamespace
              AND p.proname IN ('can_write_workspace','has_workspace_access','is_founder','is_admin','is_account_active',
                                'account_not_suspended','is_conversation_participant','has_accepted_nda')
  LOOP
    IF v_expected ? r.sig AND v_expected->>r.sig <> r.m THEN
      RAISE EXCEPTION 'rc12: definicao de public.% divergente (md5 %), envie pg_get_functiondef antes de aplicar', r.sig, r.m;
    END IF;
  END LOOP;
END $guard$;

-- Helpers de conjunto (equivalentes exatos, repartidos em parte global + conjunto de workspaces do utilizador).
CREATE OR REPLACE FUNCTION public.has_global_workspace_access()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT public.is_admin()
      OR (public.account_not_suspended(auth.uid()) AND EXISTS (
            SELECT 1 FROM public.user_roles
             WHERE user_id = auth.uid() AND role = 'consultor'::public.app_role))
$$;

-- Parte global de can_write_workspace(uuid): exige conta aprovada (is_account_active(uuid)) tambem para admin/consultor.
CREATE OR REPLACE FUNCTION public.has_global_write_access()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT public.is_account_active(auth.uid())
     AND (public.is_admin()
          OR EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role = 'consultor'::public.app_role))
$$;

CREATE OR REPLACE FUNCTION public.member_workspace_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT wu.workspace_id
    FROM public.workspace_users wu
    JOIN public.workspaces w ON w.id = wu.workspace_id
   WHERE wu.user_id = auth.uid()
     AND wu.active = true
     AND w.status <> 'blocked'
     AND w.blocked_at IS NULL
     AND public.is_account_active()
     AND (NOT EXISTS (SELECT 1 FROM public.user_roles
                       WHERE user_id = auth.uid() AND role = 'mentor_externo'::public.app_role)
          OR public.has_accepted_nda(auth.uid()))
$$;

CREATE OR REPLACE FUNCTION public.writer_workspace_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT wu.workspace_id
    FROM public.workspace_users wu
    JOIN public.workspaces w ON w.id = wu.workspace_id
   WHERE wu.user_id = auth.uid()
     AND wu.active = true
     AND wu.role IN ('founder'::public.app_role, 'consultor'::public.app_role)
     AND w.blocked_at IS NULL
     AND public.is_account_active(auth.uid())
$$;

CREATE OR REPLACE FUNCTION public.founder_workspace_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT wu.workspace_id
    FROM public.workspace_users wu
   WHERE wu.user_id = auth.uid()
     AND wu.active = true
     AND wu.role = 'founder'::public.app_role
$$;

CREATE OR REPLACE FUNCTION public.my_conversation_ids()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT conversation_id FROM public.conversation_participants WHERE user_id = auth.uid()
$$;

REVOKE ALL ON FUNCTION public.has_global_workspace_access(), public.has_global_write_access(), public.member_workspace_ids(),
                       public.writer_workspace_ids(), public.founder_workspace_ids(), public.my_conversation_ids() FROM PUBLIC;
-- anon tem de poder executar: varias politicas sao "TO public" e o Postgres avalia-as tambem para anon (devolvem vazio/false).
GRANT EXECUTE ON FUNCTION public.has_global_workspace_access(), public.has_global_write_access(), public.member_workspace_ids(),
                          public.writer_workspace_ids(), public.founder_workspace_ids(), public.my_conversation_ids()
  TO anon, authenticated, service_role;

-- Reescrita das politicas das tabelas quentes (le pg_policy, por isso parte das politicas atuais; o que nao casar fica como esta).
DO $$
DECLARE
  v_tables text[] := ARRAY[
    'action_items','milestones','sessions','documents','kpi_values','notifications','messages','conversation_participants'
  ];
  v_old_path text := current_setting('search_path');
  p record;
  v_q text; v_nq text; v_nw text; v_sql text; v_n int := 0;
BEGIN
  PERFORM set_config('search_path', 'public, pg_catalog', true);   -- pg_get_expr devolve nomes sem prefixo
  FOR p IN
    SELECT pol.oid, pol.polname, pol.polrelid, c.relname,
           pg_get_expr(pol.polqual, pol.polrelid) AS q, pg_get_expr(pol.polwithcheck, pol.polrelid) AS w
      FROM pg_policy pol JOIN pg_class c ON c.oid = pol.polrelid
     WHERE c.relnamespace = 'public'::regnamespace AND c.relname = ANY (v_tables)
  LOOP
    v_nq := p.q; v_nw := p.w;
    FOR i IN 1..2 LOOP
      v_q := CASE i WHEN 1 THEN v_nq ELSE v_nw END;
      IF v_q IS NULL THEN CONTINUE; END IF;
      -- 1) funcoes de pertenca por linha -> conjuntos
      v_q := regexp_replace(v_q, '(?<!SELECT )\yhas_workspace_access\(((?:[a-z_]+\.)?[a-z_]+)\)',
                            '((SELECT public.has_global_workspace_access()) OR \1 IN (SELECT public.member_workspace_ids()))', 'g');
      v_q := regexp_replace(v_q, '(?<!SELECT )\ycan_write_workspace\(((?:[a-z_]+\.)?[a-z_]+)\)',
                            '((SELECT public.has_global_write_access()) OR \1 IN (SELECT public.writer_workspace_ids()))', 'g');
      v_q := regexp_replace(v_q, '(?<!SELECT )\yis_founder\(((?:[a-z_]+\.)?[a-z_]+)\)',
                            '((SELECT public.is_admin()) OR \1 IN (SELECT public.founder_workspace_ids()))', 'g');
      v_q := regexp_replace(v_q, '(?<!SELECT )\yis_conversation_participant\(auth\.uid\(\), ((?:[a-z_]+\.)?[a-z_]+)\)',
                            '(\1 IN (SELECT public.my_conversation_ids()))', 'g');
      v_q := regexp_replace(v_q, '(?<!SELECT )\yis_conversation_participant\(\( SELECT auth\.uid\(\) AS uid\), ((?:[a-z_]+\.)?[a-z_]+)\)',
                            '(\1 IN (SELECT public.my_conversation_ids()))', 'g');
      -- 2) auth.uid()/auth.role() e helpers sem argumentos -> InitPlan
      v_q := regexp_replace(v_q, '(?<!SELECT )(?<![a-z_.])auth\.uid\(\)', '(SELECT auth.uid())', 'g');
      v_q := regexp_replace(v_q, '(?<!SELECT )(?<![a-z_.])auth\.role\(\)', '(SELECT auth.role())', 'g');
      v_q := regexp_replace(v_q, '(?<!SELECT )(?<![a-z_.])(is_admin|is_staff|is_backoffice|can_access_backoffice|is_admin_only|is_founder_user)\(\)',
                            '(SELECT public.\1())', 'g');
      -- 3) has_role(<uid>, '<papel>'): argumentos constantes
      v_q := regexp_replace(v_q, '(?<!SELECT )(?<![a-z_.])has_role\(\( SELECT auth\.uid\(\) AS uid\), (''[a-z_]+''::app_role)\)',
                            '(SELECT public.has_role((SELECT auth.uid()), \1))', 'g');
      v_q := regexp_replace(v_q, '(?<!SELECT )(?<![a-z_.])has_role\(\(SELECT auth\.uid\(\)\), (''[a-z_]+''::app_role)\)',
                            '(SELECT public.has_role((SELECT auth.uid()), \1))', 'g');
      IF i = 1 THEN v_nq := v_q; ELSE v_nw := v_q; END IF;
    END LOOP;
    IF v_nq IS NOT DISTINCT FROM p.q AND v_nw IS NOT DISTINCT FROM p.w THEN CONTINUE; END IF;
    v_sql := format('ALTER POLICY %I ON public.%I', p.polname, p.relname)
          || CASE WHEN v_nq IS NOT NULL THEN ' USING (' || v_nq || ')' ELSE '' END
          || CASE WHEN v_nw IS NOT NULL THEN ' WITH CHECK (' || v_nw || ')' ELSE '' END;
    EXECUTE v_sql;
    v_n := v_n + 1;
  END LOOP;
  PERFORM set_config('search_path', v_old_path, true);
  RAISE NOTICE 'RC12 DBP-04: % politicas reescritas', v_n;
END $$;
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## Lembrete de assinatura herda os contadores da fase de preenchimento (ids: CRM-08)
**Gravidade:** LOW. **Quem é afetado:** founder (recebe o email), backoffice.
**Problema:** `supabase/functions/run-intake-reminders/index.ts:205-213` usa `last_reminder_sent_at` e `reminder_count` nas duas fases (preenchimento e assinatura) e nunca os repõe ao entrar em `signature_sent`: um intake com lembretes de há 20 dias recebe "Assinatura pendente" (com novo link, que invalida o anterior) na primeira corrida do cron a seguir ao envio do contrato, em vez de aos D+3.
**Correção:** Trigger `BEFORE UPDATE OF status` em `contract_intakes` que, ao mudar para `signature_sent` ou `changes_requested` sem que o próprio UPDATE mexa nos contadores, repõe `reminder_count = 0` e `last_reminder_sent_at = NULL`. O UPDATE do cron (que só grava os contadores) não é anulado. Função e trigger novos (não substitui objetos existentes). Testes em `rc12_sql_db_triggers.test.sql` (ver secção E2E-04).
**Criar `supabase/migrations/20261103209000_rc12_intake_reminders_reset.sql`** (conteúdo exato):

```sql
-- RC12 (sql_db) · CRM-08 — lembretes de intake: a fase de assinatura recomeca a contagem.
-- run-intake-reminders usa reminder_count / last_reminder_sent_at nas duas fases (preenchimento e assinatura) e nunca os repunha
-- ao entrar em 'signature_sent': um intake com lembretes antigos recebia "Assinatura pendente" logo na primeira corrida do cron
-- a seguir ao envio do contrato (com novo link, que invalida o anterior), em vez de aos D+3.
-- Idempotente (CREATE OR REPLACE / DROP TRIGGER IF EXISTS).
CREATE OR REPLACE FUNCTION public.reset_intake_reminders_on_phase_change()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO 'public'
AS $$
BEGIN
  -- Ao entrar em 'signature_sent' ou 'changes_requested' a contagem recomeca, salvo se a propria instrucao UPDATE
  -- ja mexeu nesses campos (o UPDATE do cron nao toca em status, por isso nao e anulado).
  IF NEW.status IS DISTINCT FROM OLD.status
     AND NEW.status IN ('signature_sent', 'changes_requested')
     AND NEW.reminder_count IS NOT DISTINCT FROM OLD.reminder_count
     AND NEW.last_reminder_sent_at IS NOT DISTINCT FROM OLD.last_reminder_sent_at THEN
    NEW.reminder_count := 0;
    NEW.last_reminder_sent_at := NULL;
  END IF;
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS trg_reset_intake_reminders ON public.contract_intakes;
CREATE TRIGGER trg_reset_intake_reminders
  BEFORE UPDATE OF status ON public.contract_intakes
  FOR EACH ROW EXECUTE FUNCTION public.reset_intake_reminders_on_phase_change();
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## Higiene de integridade: updated_at parado, FKs em falta e trigger duplicado em auth.users (ids: DBP-10, DBP-11, DBP-12)
**Gravidade:** LOW. **Quem é afetado:** admin, mentor_externo e quem ordena por "última alteração".
**Problema:** (DBP-10) 11 tabelas têm `updated_at` mas nenhum trigger o atualiza (`investors`, `funding_rounds`, `cap_table_entries`, `workflow_rules`, `saved_filters`, `stage_gate_criteria`, `health_model_templates`, `contract_notices`, `crm_import_conflicts`, `crm_lead_import_batches`, `contract_field_ownership`): a coluna fica sempre com a data de criação. (DBP-11) `mentor_connections.workspace_id` e `sessions.session_template_id` não têm FK (apagar um workspace deixa a ligação mentor-workspace órfã, e essa ligação alimenta políticas de acesso); `survey_writebacks.applied_by` é a única FK de `public` para `auth.users` com `NO ACTION`, pelo que apagar fisicamente o utilizador que aplicou um writeback falha. (DBP-12) `auth.users` tem dois triggers (`on_auth_user_created_assign_role`, criado em `supabase/migrations/20260101124809_27ae575f-bc9d-4cc4-aab2-ea767f777aca.sql:32`, e `on_auth_user_created_role`, `20260101131226_e3c11b8e-8f25-4473-96c7-0b22f8c0e7df.sql:33`) a chamar `handle_new_user_role`, que corre duas vezes por registo (inofensivo por causa do `ON CONFLICT DO NOTHING`, mas trabalho duplicado e risco de divergência).
**Correção:** Migração idempotente com quatro blocos. (1) Trigger `BEFORE UPDATE ... update_updated_at_column()` nas 11 tabelas. (2) As duas FKs em falta entram `NOT VALID` (protegem linhas novas sem varrer nem rejeitar as antigas): `mentor_connections.workspace_id ... ON DELETE CASCADE` (decisão consciente: apagar o workspace apaga a ligação mentor-workspace) e `sessions.session_template_id ... ON DELETE SET NULL`, com índices parciais de suporte. Depois de limpar os órfãos (consultas abaixo), valide com `ALTER TABLE public.mentor_connections VALIDATE CONSTRAINT mentor_connections_workspace_id_fkey;` e `ALTER TABLE public.sessions VALIDATE CONSTRAINT sessions_session_template_id_fkey;`. (3) `survey_writebacks_applied_by_fkey` passa a `ON DELETE SET NULL`. (4) Remove `on_auth_user_created_assign_role` e mantém `on_auth_user_created_role`; se o ambiente não permitir DDL no esquema `auth`, a migração regista um aviso e continua (impacto desprezável). As restantes colunas `*_id` sem FK (por exemplo `mentor_bookings.founder_id/mentor_id`, `time_entries.user_id`, `notifications.user_id`) precisam de decisão sua (CASCADE ou SET NULL) e não estão incluídas. Testes em `rc12_sql_db_triggers.test.sql` (ver secção E2E-04).
**Criar `supabase/migrations/20261103204000_rc12_integrity_hygiene.sql`** (conteúdo exato):

```sql
-- RC12 (sql_db) · DBP-10, DBP-11, DBP-12 — higiene de integridade (idempotente).

-- 1) DBP-10 · updated_at que nunca avancava num UPDATE (a coluna existe mas nao ha trigger).
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['investors','funding_rounds','cap_table_entries','workflow_rules','saved_filters',
                           'stage_gate_criteria','health_model_templates','contract_notices','crm_import_conflicts',
                           'crm_lead_import_batches','contract_field_ownership']
  LOOP
    IF to_regclass(format('public.%I', t)) IS NOT NULL
       AND EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name=t AND column_name='updated_at')
       AND to_regprocedure('public.update_updated_at_column()') IS NOT NULL THEN
      EXECUTE format('DROP TRIGGER IF EXISTS trg_%s_updated_at ON public.%I', t, t);
      EXECUTE format('CREATE TRIGGER trg_%s_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column()', t, t);
    END IF;
  END LOOP;
END $$;

-- 2) DBP-11 · Orfaos: colunas *_id sem FK. NOT VALID = protege linhas novas sem varrer/rejeitar as antigas.
--    Depois de limpar os orfaos (consultas no relatorio): ALTER TABLE ... VALIDATE CONSTRAINT ...
--    mentor_connections.workspace_id usa ON DELETE CASCADE (decisao consciente: apagar o workspace apaga a ligacao mentor-workspace,
--    que alimenta politicas de acesso); sessions.session_template_id usa ON DELETE SET NULL.
DO $$
BEGIN
  IF to_regclass('public.mentor_connections') IS NOT NULL THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'mentor_connections_workspace_id_fkey' AND conrelid = 'public.mentor_connections'::regclass) THEN
      ALTER TABLE public.mentor_connections
        ADD CONSTRAINT mentor_connections_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE NOT VALID;
    END IF;
    CREATE INDEX IF NOT EXISTS idx_mentor_connections_workspace_id ON public.mentor_connections (workspace_id) WHERE workspace_id IS NOT NULL;
  END IF;
  IF to_regclass('public.sessions') IS NOT NULL AND to_regclass('public.session_templates') IS NOT NULL THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'sessions_session_template_id_fkey' AND conrelid = 'public.sessions'::regclass) THEN
      ALTER TABLE public.sessions
        ADD CONSTRAINT sessions_session_template_id_fkey FOREIGN KEY (session_template_id) REFERENCES public.session_templates(id) ON DELETE SET NULL NOT VALID;
    END IF;
    CREATE INDEX IF NOT EXISTS idx_sessions_session_template_id ON public.sessions (session_template_id) WHERE session_template_id IS NOT NULL;
  END IF;
END $$;

-- 3) DBP-11 · Unica FK de public para auth.users com NO ACTION (as outras sao SET NULL/CASCADE): impedia apagar o utilizador
--    que aplicou um writeback.
DO $$
BEGIN
  IF to_regclass('public.survey_writebacks') IS NOT NULL AND EXISTS (
       SELECT 1 FROM pg_constraint WHERE conname = 'survey_writebacks_applied_by_fkey'
          AND conrelid = 'public.survey_writebacks'::regclass AND confdeltype = 'a') THEN
    ALTER TABLE public.survey_writebacks DROP CONSTRAINT survey_writebacks_applied_by_fkey;
    ALTER TABLE public.survey_writebacks
      ADD CONSTRAINT survey_writebacks_applied_by_fkey FOREIGN KEY (applied_by) REFERENCES auth.users(id) ON DELETE SET NULL;
  END IF;
END $$;

-- 4) DBP-12 · auth.users tinha dois triggers a chamar handle_new_user_role (o 2.o era redundante: a funcao usa ON CONFLICT DO NOTHING).
--    Mantem-se on_auth_user_created_role. Se o ambiente nao permitir DDL em auth, ignora-se (impacto desprezavel).
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgrelid = 'auth.users'::regclass AND tgname = 'on_auth_user_created_role' AND NOT tgisinternal)
     AND EXISTS (SELECT 1 FROM pg_trigger WHERE tgrelid = 'auth.users'::regclass AND tgname = 'on_auth_user_created_assign_role' AND NOT tgisinternal) THEN
    DROP TRIGGER on_auth_user_created_assign_role ON auth.users;
  END IF;
EXCEPTION WHEN insufficient_privilege THEN
  RAISE NOTICE 'rc12: sem permissao para alterar triggers em auth.users; on_auth_user_created_assign_role mantido';
END $$;
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## cron_invoke_edge com o URL do projeto de produção fixo (ids: OPS-13)
**Gravidade:** LOW. **Quem é afetado:** equipa técnica (staging, ensaios de restauro).
**Problema:** `v_url := 'https://apxzuslwhjujgrcsfzqw.supabase.co/functions/v1/' || p_function;` (`supabase/migrations/20260811141628_4be9d892-18f1-464a-81cd-4528baf1711c.sql:88`). Qualquer base criada a partir das migrações agenda 17 jobs que chamam as funções de PRODUÇÃO com tokens que lá não existem (401 e linhas `skipped`), e as automações do staging nunca correm.
**Correção:** `cron_invoke_edge` passa a ler o URL base de `current_setting('app.edge_base_url', true)` e, se não estiver definido, mantém o URL de produção (comportamento atual inalterado). Em staging: `ALTER DATABASE postgres SET app.edge_base_url = 'https://<ref-staging>.supabase.co';` e abrir nova sessão. Alteração mínima (só a linha de `v_url`) sobre a definição atual da base viva, com guarda de md5; `EXECUTE` continua só para `service_role`. Teste em `rc12_sql_db_retention_ops.test.sql`.
**Criar `supabase/migrations/20261103207000_rc12_cron_edge_base_url.sql`** (conteúdo exato):

```sql
-- RC12 (sql_db) · OPS-13 — cron_invoke_edge tinha o URL do projeto de producao fixo: qualquer base criada a partir das migracoes
-- (staging, ensaio de restauro) agendaria 17 jobs a chamar as funcoes de PRODUCAO com tokens que la nao existem.
-- Passa a ler o URL base de `app.edge_base_url` e, se nao estiver definido, mantem o URL de producao (comportamento atual).
-- Em staging: ALTER DATABASE postgres SET app.edge_base_url = 'https://<ref-staging>.supabase.co';  (e abrir nova sessao)
-- Alteracao minima: so a linha de v_url. A guarda de md5 aborta se a definicao real divergir da de que partimos.
DO $guard$
DECLARE v_def text; v_md5 text;
BEGIN
  SELECT pg_get_functiondef(p.oid) INTO v_def FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
   WHERE n.nspname='public' AND p.proname='cron_invoke_edge' AND pg_get_function_identity_arguments(p.oid)='p_function text, p_payload jsonb';
  v_md5 := md5(v_def);
  IF v_md5 NOT IN ('31e547c774e8660a7c5f95cf7243f042', '1f1cea717b5a1982e1704b9590026f23') THEN
    RAISE EXCEPTION 'rc12: definicao de public.cron_invoke_edge divergente (md5 %), envie o resultado de pg_get_functiondef antes de aplicar', v_md5;
  END IF;
END $guard$;

CREATE OR REPLACE FUNCTION public.cron_invoke_edge(p_function text, p_payload jsonb DEFAULT '{}'::jsonb)
 RETURNS bigint
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions', 'net'
AS $function$
DECLARE
  v_url text;
  v_token text;
  v_request_id bigint;
BEGIN
  IF p_function IS NULL OR p_function = '' THEN
    RAISE EXCEPTION 'cron_invoke_edge: function name required' USING ERRCODE = '22023';
  END IF;

  v_url := COALESCE(NULLIF(current_setting('app.edge_base_url', true), ''), 'https://apxzuslwhjujgrcsfzqw.supabase.co')
           || '/functions/v1/' || p_function;
  v_token := public.issue_cron_token(p_function);

  SELECT net.http_post(
    url := v_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-cron-token', v_token
    ),
    body := COALESCE(p_payload, '{}'::jsonb),
    timeout_milliseconds := 60000
  ) INTO v_request_id;

  RETURN v_request_id;
END;
$function$;

REVOKE ALL ON FUNCTION public.cron_invoke_edge(text, jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cron_invoke_edge(text, jsonb) TO service_role;
```

---

## Rascunho do modelo de investidor partilhado entre contas (ids: FEX-02)
**Gravidade:** LOW. **Quem é afetado:** founder, team_member e quem partilha o browser.
**Problema:** `InvestorTemplateLibrary.tsx:119` grava o rascunho em `investor_template_draft_<templateId>` sem utilizador, e `src/lib/sessionReset.ts:16-21` não o apaga no logout.
**Correção (lado `lib`):** `resetSession` passa a apagar também o prefixo antigo `investor_template_draft_`. Mudar a chave do componente para `sl-investor-draft:<userId>:<templateId>` (o prefixo `sl-` já é apagado) cabe ao domínio do founder. Não alargar a lista a `template-draft:`, `contract-*-draft:`, `celebrated_` e afins: já levam o id do utilizador e apagá-los no logout perderia rascunhos por gravar e repetiria animações. Inclui testes.
**Alterar `src/lib/sessionReset.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/src/lib/sessionReset.ts
+++ b/src/lib/sessionReset.ts
@@ -19,4 +19,6 @@ const USER_KEY_PREFIXES = [
   'shown_quickguide_',
   'sl-',
+  // Legacy key (no user id) of the investor template drafts; current ones use `sl-investor-draft:<uid>:<tpl>`
+  'investor_template_draft_',
 ];
```

---

## Tema escuro só é aplicado depois do bundle de idioma (ids: FEX-20)
**Gravidade:** LOW. **Quem é afetado:** quem usa tema escuro.
**Problema:** a classe `.dark` só é posta pelo `ThemeProvider` depois de `initI18n()` (`src/main.tsx:53`), por isso a página arranca clara e muda. `index.html` não tem nenhum script de tema.
**Correção:** script inline em `index.html`, antes do `<title>`, que aplica `dark`/`light` a partir de `localStorage.theme` e de `prefers-color-scheme` (compatível com o `ThemeProvider`, que remove e volta a pôr a classe). Nota: `index.html` está fora de `src/`.
**Alterar `index.html`** (diff; os números de linha são do ficheiro original):

```diff
--- a/index.html
+++ b/index.html
@@ -8,4 +8,12 @@
     <meta http-equiv="Pragma" content="no-cache" />
     <meta http-equiv="Expires" content="0" />
+    <!-- Apply the saved theme before first paint (ThemeProvider only runs after the locale bundle loads) -->
+    <script>
+      try {
+        var t = localStorage.getItem('theme');
+        var dark = t === 'dark' || ((!t || t === 'system') && window.matchMedia('(prefers-color-scheme: dark)').matches);
+        document.documentElement.classList.add(dark ? 'dark' : 'light');
+      } catch (e) {}
+    </script>
     <title>Startup Leiria Portal | Plataforma de Mentoria para Startups</title>
     <meta name="description" content="Plataforma de acompanhamento e mentoria de startups. Gestão de sessões, KPIs, milestones e integração com Microsoft Teams." />
```



## Textos de i18n: chaves em falta, plurais e en.json em português (ids: FES-09, FEX-07, OPS-08, FEF-06, FEX-08, FEB-09)
**Gravidade:** LOW. **Quem é afetado:** quem usa a app em inglês; CI (gates `i18n:lint` e `i18n-sync-guard`).
**Problema:** (a) `PendingApprovalsManager.tsx:738,746,754,756` usa 4 chaves `admin.*` que não existem nos catálogos (8 problemas no `i18n:lint`); (b) 26 chaves `X_plural` em `pt.json`/`en.json` são ignoradas com `compatibilityJSON: 'v4'` (`src/i18n/index.ts:24`), por isso "há 5 dia" e "15 startup"; (c) `en.json` tem 116 valores em português ou misturados (ex.: `login.backToLogin`, `bugReport.*`, `admin.erroAoGerarRelatório`) e 17 chaves iguais ao português (`admin.userManagement.cannotSuspendSelf`, `common.open`, `nav.admin.diagnostics`, ...); `pt.json` tem `cannotSuspendSelf` com tratamento por "tu".
**Correção:** as chaves são acrescentadas pela ferramenta de i18n (ficheiro `rc12/i18n/f_shell.json`), não à mão: as 4 chaves `admin.chooseWorkspace`, `searchWorkspace`, `wsStatusActive`, `wsStatusUnclaimed`; as chaves `X_one` e `X_other` para cada `X_plural` (mantém `X` e `X_plural`, porque o guard do CI falha se uma chave for removida); a tradução inglesa de 121 valores acima (valores de `en.json` já existentes, substituídos) e `admin.userManagement.cannotSuspendSelf` em pt = "Não pode suspender a sua própria conta". Em `en.json` a chave `backoffice.edifícioCriado` mantém o acento (é a chave usada no código).


## Gates e testes de segurança tautológicos (ids: FEX-21)
**Gravidade:** LOW. **Quem é afetado:** engenharia.
**Problema:** `src/test/auth.test.ts` reimplementa as regras em vez de importar o código; `sessionReset`, `sanitizeUrl`, `logError`, `lazyWithRetry` e a lógica de contagens não tinham testes.
**Correção:** os testes novos acompanham as correções acima (`sanitizeUrl.test.ts`, `sessionReset.test.ts`, `logError.redact.test.ts`, `queryCount.test.ts`, `lazyWithRetry.storage.test.ts`, `useChecklistRecovery.storage.test.tsx`, `SessionTimeoutWarning.test.tsx`, `useAttentionCount.test.tsx`), já incluídos nos marcadores `{{DIFF}}` dos temas respetivos. Fica por fazer um teste de `ProtectedRoute` com `AuthContext` simulado.

---

## staff-assign-workspace-to-contract: guarda de program_id repetida três vezes (ids: E2E-13, SIGN-12)
**Gravidade:** LOW. **Quem é afetado:** admin, consultor, backoffice (manutenção).
**Problema:** `supabase/functions/staff-assign-workspace-to-contract/index.ts:93-104` repete três vezes o mesmo bloco `if (!programId) return errorResponse(...)` com o mesmo comentário (resíduo de aplicar o C13/SIGN-14 do RC10 várias vezes). As duas últimas são código morto.
**Correção:** apagar as linhas 97-104, mantendo só a primeira guarda.
**Alterar `supabase/functions/staff-assign-workspace-to-contract/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/staff-assign-workspace-to-contract/index.ts
+++ b/supabase/functions/staff-assign-workspace-to-contract/index.ts
@@ -95,12 +95,4 @@ Deno.serve(async (req) => {
         return errorResponse(req, 'program_id required to create workspace', ErrorCode.BAD_REQUEST, 400);
       }
-      // workspaces.program_id é NOT NULL: sem programa o insert falhava e deixava uma startup órfã
-      if (!programId) {
-        return errorResponse(req, "program_id required to create workspace", ErrorCode.BAD_REQUEST, 400);
-      }
-      // workspaces.program_id é NOT NULL: sem programa o insert falhava e deixava uma startup órfã
-      if (!programId) {
-        return errorResponse(req, "program_id required to create workspace", ErrorCode.BAD_REQUEST, 400);
-      }
 
       // Duplicate guard: same startup name + program already has a non-archived workspace.
```

---

## O lembrete de «Correções pedidas» não leva as notas das correções (ids: CRM-09)
**Gravidade:** LOW. **Quem é afetado:** anónimo (founder), backoffice.
**Problema:** `supabase/functions/run-intake-reminders/index.ts:102,144-151` envia `type:'changes_requested'` sem `changesNotes`; o email diz «identificou alguns pontos que necessitam de correção:» e não mostra nenhum.
**Correção:** acrescentar `changes_requested_notes` ao select e passá-lo como `changesNotes` quando o estado é `changes_requested`. Fazer deploy de `run-intake-reminders`.
**Alterar `supabase/functions/run-intake-reminders/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/run-intake-reminders/index.ts
+++ b/supabase/functions/run-intake-reminders/index.ts
@@ -100,5 +100,5 @@ Deno.serve(withCronRunLogging('run-intake-reminders', async (req) => {
     const { data: pendingIntakes, error: intakesErr } = await supabase
       .from('contract_intakes')
-      .select('id, organization_name, legal_representative_email, legal_representative_name, created_at, last_reminder_sent_at, reminder_count, status, updated_at')
+      .select('id, organization_name, legal_representative_email, legal_representative_name, created_at, last_reminder_sent_at, reminder_count, status, updated_at, changes_requested_notes')
       .in('status', ['intake_requested', 'intake_in_progress', 'changes_requested'])
       .not('legal_representative_email', 'is', null)
@@ -149,4 +149,6 @@ Deno.serve(withCronRunLogging('run-intake-reminders', async (req) => {
           organizationName: intake.organization_name,
           intakeToken: freshToken,
+          // o lembrete de correções tem de repetir o que há a corrigir
+          ...(intake.status === 'changes_requested' ? { changesNotes: intake.changes_requested_notes ?? undefined } : {}),
         }, serviceKey)
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## commit-crm-import: sem reclamação do job, `row_ids` vazio comita tudo e corpo inválido dá 500 (ids: ED1-10)
**Gravidade:** LOW. **Quem é afetado:** admin (importador de dados V2).
**Problema:** `commit-crm-import/index.ts:169` põe o job em `committing` sem verificar o estado anterior: um segundo pedido (reenvio depois de o browser desistir de um commit longo) corre em paralelo sobre as mesmas linhas `approved` e as leads sem ids externos ficam duplicadas. `row_ids: []` é tratado como "sem filtro" (`:172`, `[]?.length` é falsy) e comita todas as linhas aprovadas; `req.json()` sem `catch` (`:149`) devolve 500 em vez de 400; o job fica `committed` mesmo com falhas ou linhas `stale` (`:248-252`); o 500 devolve `e.message` (texto de Postgres) ao cliente (`:257`).
**Correção:** corpo inválido, `job_id` que não seja UUID e `row_ids` presente mas vazio, com mais de 5000 itens ou com valores que não sejam UUID passam a dar 400; o job é reclamado com um UPDATE condicional (`status<>'committing'` ou `updated_at` com mais de 15 minutos) e um segundo pedido recebe 409 `job_already_committing`; o job fecha como `committed_with_errors` se houve falhas ou linhas `stale` (valor novo, que nenhum consumidor lê; a UI não depende do estado do job) e o erro do UPDATE final fica no log; o 500 devolve só `internal_error`. Aviso: se a execução lançar uma exceção depois de reclamar o job, este fica em `committing` e um retry dentro dos 15 minutos seguintes recebe 409. Depois de publicar, faça deploy de `commit-crm-import`.
**Alterar `supabase/functions/commit-crm-import/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/commit-crm-import/index.ts
+++ b/supabase/functions/commit-crm-import/index.ts
@@ -147,6 +147,14 @@ Deno.serve(async (req) => {
     if (!isAdmin) return new Response(JSON.stringify({ error: 'forbidden' }), { status: 403, headers: jsonHeaders });
 
-    const body = await req.json() as CommitBody;
-    if (!body?.job_id) return new Response(JSON.stringify({ error: 'invalid_input' }), { status: 400, headers: jsonHeaders });
+    const body = await req.json().catch(() => null) as CommitBody | null;
+    const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
+    // row_ids, quando enviado, tem de ser uma lista não vazia de UUIDs (uma lista vazia comitava todas as linhas aprovadas).
+    const rowIdsInvalid = body?.row_ids != null && (
+      !Array.isArray(body.row_ids) || body.row_ids.length === 0 || body.row_ids.length > 5000 ||
+      !body.row_ids.every((v: unknown) => typeof v === 'string' && UUID_RE.test(v))
+    );
+    if (!body || typeof body.job_id !== 'string' || !UUID_RE.test(body.job_id) || rowIdsInvalid) {
+      return new Response(JSON.stringify({ error: 'invalid_input' }), { status: 400, headers: jsonHeaders });
+    }
 
     const { data: job, error: jobErr } = await sbSvc.from('data_import_jobs').select('*').eq('id', body.job_id).single();
@@ -167,5 +175,15 @@ Deno.serve(async (req) => {
     }
 
-    await sbSvc.from('data_import_jobs').update({ status: 'committing', approved_by: uid }).eq('id', job.id);
+    // Reclamação atómica do job: um segundo pedido em simultâneo recebe 409 (um job preso em 'committing' há mais de 15 min pode ser retomado).
+    const staleBefore = new Date(Date.now() - 15 * 60 * 1000).toISOString();
+    const { data: claimedJob, error: claimErr } = await sbSvc.from('data_import_jobs')
+      .update({ status: 'committing', approved_by: uid })
+      .eq('id', job.id)
+      .or(`status.neq.committing,updated_at.lt.${staleBefore}`)
+      .select('id');
+    if (claimErr) throw claimErr;
+    if (!claimedJob?.length) {
+      return new Response(JSON.stringify({ error: 'job_already_committing' }), { status: 409, headers: jsonHeaders });
+    }
 
     let q = sbSvc.from('data_import_rows').select('*').eq('job_id', job.id).eq('approval_state', 'approved');
@@ -246,14 +264,15 @@ Deno.serve(async (req) => {
     }
 
-    await sbSvc.from('data_import_jobs').update({
-      status: 'committed',
+    const { error: jobDoneErr } = await sbSvc.from('data_import_jobs').update({
+      status: summary.failed > 0 || summary.stale > 0 ? 'committed_with_errors' : 'committed',
       committed_at: new Date().toISOString(),
       counts_json: { ...(job.counts_json ?? {}), commit: summary },
     }).eq('id', job.id);
+    if (jobDoneErr) console.error('commit-crm-import: failed to finalize job', jobDoneErr.message);
 
     return new Response(JSON.stringify({ success: true, source, summary, sample: results.slice(0, 20) }), { headers: jsonHeaders });
   } catch (e: any) {
     console.error('commit-crm-import error', e?.message ?? e);
-    return new Response(JSON.stringify({ error: 'internal_error', message: e?.message ?? String(e) }), {
+    return new Response(JSON.stringify({ error: 'internal_error' }), {
       status: 500, headers: jsonHeaders,
     });
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## accept-mentor-nda reescreve a data e o IP do 1.º aceite e usa um sal fixo (ids: ED2-13)
**Gravidade:** LOW. **Quem é afetado:** mentor_externo.
**Problema:** `accept-mentor-nda/index.ts:46-56` faz upsert com `onConflict` e `accepted_at` novo: cada vez que o mentor volta a carregar em aceitar, a data, o `ip_hash` e o `user_agent` do 1.º aceite perdem-se; a resposta (`:71`) devolve um segundo `new Date()` diferente do gravado. O `ip_hash` é SHA-256 de `ip + 'salt-for-privacy'` truncado a 8 bytes (`:39-43`): o sal está no código e o espaço IPv4 é pequeno, logo é reversível por força bruta.
**Correção:** o `ip_hash` passa a ser um HMAC-SHA-256 com `SUPABASE_SERVICE_ROLE_KEY` como segredo (os hashes novos deixam de ser comparáveis com os antigos); o upsert passa a `ignoreDuplicates: true` (ON CONFLICT DO NOTHING), sem `accepted_at` (usa o `DEFAULT now()`), preservando o 1.º aceite; a resposta lê o `accepted_at` realmente gravado. A RLS continua a recusar quem não é mentor. Depois de publicar, faça deploy de `accept-mentor-nda`.
**Alterar `supabase/functions/accept-mentor-nda/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/accept-mentor-nda/index.ts
+++ b/supabase/functions/accept-mentor-nda/index.ts
@@ -37,11 +37,15 @@ Deno.serve(async (req: Request) => {
                      'unknown';
 
-    const encoder = new TextEncoder();
-    const data = encoder.encode(clientIp + 'salt-for-privacy');
-    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
-    const hashArray = Array.from(new Uint8Array(hashBuffer));
-    const ipHash = hashArray.slice(0, 8).map(b => b.toString(16).padStart(2, '0')).join('');
+    // HMAC com segredo do servidor (o sal fixo no código tornava o hash reversível por força bruta).
+    const hmacKey = await crypto.subtle.importKey(
+      'raw', new TextEncoder().encode(Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? 'nda-ip-hash'),
+      { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
+    );
+    const sig = await crypto.subtle.sign('HMAC', hmacKey, new TextEncoder().encode(clientIp));
+    const ipHash = Array.from(new Uint8Array(sig)).slice(0, 8).map(b => b.toString(16).padStart(2, '0')).join('');
 
-    // Upsert NDA acceptance — RLS ensures only mentor_externo users can insert/update their own row
+    // Regista o aceite — RLS garante que só mentor_externo insere a sua própria linha.
+    // O 1.º aceite é a prova: ignoreDuplicates (ON CONFLICT DO NOTHING) não reescreve data nem IP,
+    // e accepted_at fica com o DEFAULT now() da tabela.
     const { error: upsertError } = await supabase
       .from('mentor_nda_acceptances')
@@ -51,7 +55,7 @@ Deno.serve(async (req: Request) => {
         ip_hash: ipHash,
         user_agent: userAgent?.substring(0, 500),
-        accepted_at: new Date().toISOString(),
       }, {
-        onConflict: 'user_id,nda_version'
+        onConflict: 'user_id,nda_version',
+        ignoreDuplicates: true,
       });
 
@@ -65,9 +69,17 @@ Deno.serve(async (req: Request) => {
     }
 
+    // Devolve a data realmente gravada (a do 1.º aceite, se já existia)
+    const { data: stored } = await supabase
+      .from('mentor_nda_acceptances')
+      .select('accepted_at')
+      .eq('user_id', userId)
+      .eq('nda_version', CURRENT_NDA_VERSION)
+      .maybeSingle();
+
     return corsJsonResponse({
       success: true,
       message: 'NDA accepted successfully',
       nda_version: CURRENT_NDA_VERSION,
-      accepted_at: new Date().toISOString(),
+      accepted_at: stored?.accepted_at ?? new Date().toISOString(),
     }, req);
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## commit-hubspot-import: dupla invocação duplica funnel_items e aceita jobs que não são HubSpot (ids: ED2-14)
**Gravidade:** LOW. **Quem é afetado:** admin (função sem chamador na UI; o importador V2 usa `commit-crm-import`).
**Problema:** duas invocações em simultâneo leem as mesmas linhas `approved` (`commit-hubspot-import/index.ts:51-53`) e chamam `commit_import_funnel_item`, que não marca a linha: ambas inserem. Não há verificação de `job.source` (um job PHC passa e é gravado com payload HubSpot); os erros dos UPDATE ao job (`:49`, `:148-152`) são ignorados, uma exceção a meio deixa o job em `committing` e o 500 devolve `e.message`.
**Correção:** `job.source` tem de ser `hubspot` (400 `unsupported_source`); corpo inválido não rebenta; o UPDATE de `committing` e o final lançam em caso de erro; cada linha é reclamada com um UPDATE condicional `approval_state: 'approved' -> 'committing'` antes de qualquer trabalho (quem não reclama conta como `skipped`); o 500 devolve só `internal_error`. Aviso: uma linha reclamada e não concluída porque o processo morreu fica em `committing` e tem de ser reposta à mão. Alternativa válida: apagar a função, que não tem chamadores. Depois de publicar, faça deploy de `commit-hubspot-import`.
**Alterar `supabase/functions/commit-hubspot-import/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/commit-hubspot-import/index.ts
+++ b/supabase/functions/commit-hubspot-import/index.ts
@@ -41,5 +41,5 @@ Deno.serve(async (req) => {
     if (!isAdmin) return new Response(JSON.stringify({ error: 'forbidden' }), { status: 403, headers: jsonHeaders });
 
-    const body = await req.json() as CommitBody;
+    const body = await req.json().catch(() => null) as CommitBody | null;
     if (!body?.job_id) return new Response(JSON.stringify({ error: 'invalid_input' }), { status: 400, headers: jsonHeaders });
 
@@ -47,5 +47,10 @@ Deno.serve(async (req) => {
     if (jobErr || !job) return new Response(JSON.stringify({ error: 'job_not_found' }), { status: 404, headers: jsonHeaders });
 
-    await sbSvc.from('data_import_jobs').update({ status: 'committing', approved_by: uid }).eq('id', job.id);
+    if (job.source !== 'hubspot') {
+      return new Response(JSON.stringify({ error: 'unsupported_source' }), { status: 400, headers: jsonHeaders });
+    }
+
+    const { error: claimJobErr } = await sbSvc.from('data_import_jobs').update({ status: 'committing', approved_by: uid }).eq('id', job.id);
+    if (claimJobErr) throw claimJobErr;
 
     let q = sbSvc.from('data_import_rows').select('*').eq('job_id', job.id).eq('approval_state', 'approved');
@@ -65,4 +70,11 @@ Deno.serve(async (req) => {
       await Promise.all(slice.map(async (row: any) => {
         try {
+          // Reclamação atómica da linha: duas invocações em simultâneo não inserem a mesma linha duas vezes.
+          const { data: claimed, error: claimErr } = await sbSvc.from('data_import_rows')
+            .update({ approval_state: 'committing' })
+            .eq('id', row.id).eq('approval_state', 'approved').select('id');
+          if (claimErr) throw claimErr;
+          if (!claimed || claimed.length === 0) { summary.skipped++; return; }
+
           const n = row.normalized_json ?? {};
           const toggles = row.approve_toggles_json ?? {};
@@ -146,14 +158,15 @@ Deno.serve(async (req) => {
     }
 
-    await sbSvc.from('data_import_jobs').update({
+    const { error: jobDoneErr } = await sbSvc.from('data_import_jobs').update({
       status: summary.failed > 0 ? 'committed' : 'committed', // keep single status; failures visible per row
       committed_at: new Date().toISOString(),
       counts_json: { ...(job.counts_json ?? {}), commit: summary },
     }).eq('id', job.id);
+    if (jobDoneErr) throw jobDoneErr;
 
     return new Response(JSON.stringify({ success: true, summary, sample: results.slice(0, 20) }), { headers: jsonHeaders });
   } catch (e: any) {
     console.error('commit-hubspot-import error', e?.message ?? e);
-    return new Response(JSON.stringify({ error: 'internal_error', message: e?.message ?? String(e) }), {
+    return new Response(JSON.stringify({ error: 'internal_error' }), {
       status: 500, headers: jsonHeaders,
     });
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## accept-workspace-invite: corpo JSON inválido dá 500 (ids: ED2-15)
**Gravidade:** LOW. **Quem é afetado:** qualquer utilizador autenticado com um link de convite.
**Problema:** `accept-workspace-invite/index.ts:42-43` faz `await req.json()` sem `catch`: um corpo que não seja JSON lança e responde 500 em vez de 400. (O outro defeito do achado, o RPC `accept_workspace_invitation` devolver `workspace_id`/`startup_id` de um convite já aceite antes de comparar o e-mail, é uma migração de base de dados e fica a cargo de quem a escreve: ver `cross_domain`.)
**Correção:** `req.json().catch(() => null)` e o token passa a validar-se com `/^[0-9a-f]{64}$/i` (o token gerado em `send-workspace-invite` tem sempre 32 bytes em hexadecimal), devolvendo 400 "Invalid invitation token". Depois de publicar, faça deploy de `accept-workspace-invite`.
**Alterar `supabase/functions/accept-workspace-invite/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/accept-workspace-invite/index.ts
+++ b/supabase/functions/accept-workspace-invite/index.ts
@@ -40,6 +40,6 @@ serve(async (req) => {
     }
 
-    const payload: AcceptInviteRequest = await req.json();
-    if (!payload.token || typeof payload.token !== 'string' || payload.token.length !== 64) {
+    const payload = await req.json().catch(() => null) as AcceptInviteRequest | null;
+    if (!payload || typeof payload.token !== 'string' || !/^[0-9a-f]{64}$/i.test(payload.token)) {
       return corsJsonResponse({ error: "Invalid invitation token" }, req, 400);
     }
```
