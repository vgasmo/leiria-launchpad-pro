# PROMPT LOVABLE — RC12 · PARTE OPCIONAL 2 de 3 — apply-survey-responses: autenticar antes de ler,… · Convite da sessão falha em silêncio no diálogo… · copilot-apply-playbook: o preflight não reflete o RLS… [LOW]

**Regras (as mesmas da Parte 1, em resumo):** aplique só o que está nesta parte; os diffs são `-U2` com números de linha do ficheiro ORIGINAL e, se um não aplicar, pare nessa secção e diga qual; "Criar" = ficheiro novo com o conteúdo exato; as migrações SQL são idempotentes, correm numa transação e os blocos `DO $guard$` abortam de propósito se a função real divergiu (devolva o `md5` e o `pg_get_functiondef`, nunca desative o guarda); não edite migrações existentes nem `types.ts`; publique as edge functions alteradas; no fim responda com as secções aplicadas, as não aplicadas (com razão) e qualquer erro, com o texto exato.

**Edge functions alteradas nesta parte:** apply-survey-responses, check-missed-milestones, copilot-apply-playbook, dataroom-revoke-link, export-cohort-health-pdf, generate-financial-prefill, recompute-health-scores, run-ecosystem-snapshot, run-workflow-rules, send-announcement-email, send-commercial-proposal, send-email-digest, send-intake-email, send-notification-email, send-session-invite, sync-graph-email-history.

---

## apply-survey-responses: autenticar antes de ler, auditoria preservada e marco duplicado (ids: ED2-10, ED2-11, ED2-12)
**Gravidade:** LOW. **Quem é afetado:** founder, consultor, admin; anónimo (oráculo de ids).
**Problema:** (ED2-10) `apply-survey-responses/index.ts:387-403` (`verify_jwt=false`) consulta `survey_instances` com o service role e responde 404 antes de pedir credenciais, por isso um anónimo distingue instâncias existentes (404 vs 401/403); o `x-cron-secret` é comparado com `===`. (ED2-11) Nada marca a instância como aplicada: uma segunda chamada refaz tudo, `periodMonth` usa `new Date()` (um retry no mês seguinte grava os KPI no mês errado) e as linhas de `survey_writebacks` são apagadas e reinseridas, pelo que as `applied` (com `anterior: ...`, a única informação de anulação) passam a `skipped: Campo já preenchido`, sem ler o erro do insert. (ED2-12) O marco existente é procurado com `.ilike('title', title)`, onde `%` e `_` são curingas (um título `100%` casa com outros marcos), e `.maybeSingle()` falha com 2 ou mais correspondências, deixando `existing = null` e inserindo o marco outra vez em cada execução.
**Correção:** o `x-cron-secret` passa por `timingSafeEqual` e a autenticação (JWT) corre antes de carregar a instância, guardando `authedUserId`; só depois vêm a instância, `has_workspace_access` e a verificação de papel. O select da instância ganha `submitted_at` e `periodMonth` usa o mês da submissão. A auditoria faz `upsert` por `(instance_id, question_id)` (a constraint única existe) sem rebaixar linhas `applied` para `skipped`, e um erro da auditoria passa a lançar. A procura do marco escapa `\`, `%` e `_`, troca `*` (curinga do PostgREST) por `_` e usa `.limit(1)`. Fica por resolver (fora deste LOW) que `applyKpi` substitui um valor manual do mesmo mês sem registar o valor anterior.
**Alterar `supabase/functions/apply-survey-responses/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/apply-survey-responses/index.ts
+++ b/supabase/functions/apply-survey-responses/index.ts
@@ -2,5 +2,5 @@ import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-
 import { getCorsHeaders, handleCorsOptions } from '../_shared/cors.ts';
 import { validateUUID, parseAndValidateBody } from '../_shared/validation.ts';
-import { isServiceRoleBearer } from '../_shared/security.ts';
+import { isServiceRoleBearer, timingSafeEqual } from '../_shared/security.ts';
 
 /**
@@ -303,10 +303,12 @@ async function applyMilestone(
   const title = answer.trim().slice(0, 200);
 
-  const { data: existing } = await supabase
+  // ilike trata % e _ (e * no PostgREST) como wildcards e maybeSingle() falha com 2+ linhas (-> duplicava o marco).
+  const { data: existingRows } = await supabase
     .from('milestones')
     .select('id')
     .eq('workspace_id', workspaceId)
-    .ilike('title', title)
-    .maybeSingle();
+    .ilike('title', title.replace(/[\\%_]/g, '\\$&').replace(/\*/g, '_'))
+    .limit(1);
+  const existing = existingRows?.[0] ?? null;
 
   if (existing) {
@@ -385,8 +387,26 @@ Deno.serve(async (req) => {
     const instanceId = instanceIdResult.value!;
 
+    // Auth: the founder's own JWT, or an internal call carrying the cron secret.
+    // Autenticar ANTES de ler survey_instances (service role): sem sessão não há oráculo 404/403.
+    const providedCron = req.headers.get('x-cron-secret');
+    const isInternal = isServiceRoleBearer(req)
+      || (Boolean(cronSecret) && providedCron !== null && timingSafeEqual(providedCron, cronSecret!));
+    let authedUserId: string | null = null;
+
+    if (!isInternal) {
+      const authHeader = req.headers.get('Authorization');
+      if (!authHeader) return json({ error: 'Unauthorized' }, 401);
+
+      const { data: { user }, error: authError } = await supabase.auth.getUser(
+        authHeader.replace('Bearer ', ''),
+      );
+      if (authError || !user) return json({ error: 'Unauthorized' }, 401);
+      authedUserId = user.id;
+    }
+
     const { data: instance, error: instanceError } = await supabase
       .from('survey_instances')
       .select(`
-        id, workspace_id, status, submitted_by,
+        id, workspace_id, status, submitted_by, submitted_at,
         campaign:survey_campaigns(
           id, name,
@@ -400,19 +420,9 @@ Deno.serve(async (req) => {
     if (!instance) return json({ error: 'Survey instance not found' }, 404);
 
-    // Auth: the founder's own JWT, or an internal call carrying the cron secret.
-    const isInternal = isServiceRoleBearer(req) || (Boolean(cronSecret) && req.headers.get('x-cron-secret') === cronSecret);
     let userId: string | null = null;
 
-    if (!isInternal) {
-      const authHeader = req.headers.get('Authorization');
-      if (!authHeader) return json({ error: 'Unauthorized' }, 401);
-
-      const { data: { user }, error: authError } = await supabase.auth.getUser(
-        authHeader.replace('Bearer ', ''),
-      );
-      if (authError || !user) return json({ error: 'Unauthorized' }, 401);
-
+    if (authedUserId) {
       const { data: hasAccess } = await supabase.rpc('has_workspace_access', {
-        _user_id: user.id,
+        _user_id: authedUserId,
         _workspace_id: instance.workspace_id,
       });
@@ -421,7 +431,7 @@ Deno.serve(async (req) => {
       const [{ data: staffRoles }, { data: founderRows }] = await Promise.all([
         supabase.from('user_roles').select('role')
-          .eq('user_id', user.id).in('role', ['admin', 'consultor']),
+          .eq('user_id', authedUserId).in('role', ['admin', 'consultor']),
         supabase.from('workspace_users').select('id')
-          .eq('workspace_id', instance.workspace_id).eq('user_id', user.id)
+          .eq('workspace_id', instance.workspace_id).eq('user_id', authedUserId)
           .eq('active', true).eq('role', 'founder').limit(1),
       ]);
@@ -430,5 +440,5 @@ Deno.serve(async (req) => {
       }
 
-      userId = user.id;
+      userId = authedUserId;
     } else {
       userId = instance.submitted_by ?? null;
@@ -474,5 +484,6 @@ Deno.serve(async (req) => {
       .single();
 
-    const periodMonth = startOfMonth(new Date());
+    // O período é o mês da submissão, não o de agora: um reenvio/retry tardio não pode gravar noutro mês.
+    const periodMonth = startOfMonth(instance.submitted_at ? new Date(instance.submitted_at) : new Date());
     const results: WriteBackResult[] = [];
 
@@ -533,14 +544,24 @@ Deno.serve(async (req) => {
     }
 
-    // Re-running the survey replaces the previous audit rows for the instance.
-    await supabase.from('survey_writebacks').delete().eq('instance_id', instanceId);
-    await supabase.from('survey_writebacks').insert(
-      results.map((result) => ({
+    // Re-running the survey updates the audit rows, but never downgrades a row that
+    // already recorded an applied write ("anterior: ..." is the only undo information).
+    const { data: previousRows, error: previousError } = await supabase
+      .from('survey_writebacks').select('question_id, status').eq('instance_id', instanceId);
+    if (previousError) throw previousError;
+    const alreadyApplied = new Set((previousRows ?? []).filter((r) => r.status === 'applied').map((r) => r.question_id));
+    const auditRows = results
+      .filter((result) => !(result.status === 'skipped' && alreadyApplied.has(result.question_id)))
+      .map((result) => ({
         ...result,
         instance_id: instanceId,
         workspace_id: instance.workspace_id,
         applied_by: userId,
-      })),
-    );
+      }));
+    if (auditRows.length > 0) {
+      const { error: auditError } = await supabase
+        .from('survey_writebacks')
+        .upsert(auditRows, { onConflict: 'instance_id,question_id' });
+      if (auditError) throw auditError;
+    }
 
     const applied = results.filter((r) => r.status === 'applied').length;
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## check-missed-milestones: o 2.º marco em atraso perde o item da fila (ids: ED1-08, SCH-17)
**Gravidade:** LOW. **Quem é afetado:** consultor e admin (fila de trabalho do staff).
**Problema:** `staff_work_queue_items` tem o índice único `idx_work_queue_unique_active (workspace_id, type)` para itens `open`/`in_progress`. Quando um workspace tem 2 marcos em atraso (ou já existe um item aberto), o `INSERT` do 2.º falha com 23505 e `check-missed-milestones/index.ts:141-157` só testa `!alertError && alertData`: o marco fica `delayed`, cria-se a ação e envia-se o Teams, mas a fila só mostra um marco. O `fetch` ao `teams-notify` (`:20-32`) não tem timeout e é sequencial, pelo que um pedido pendurado bloqueia o cron inteiro. O erro do `UPDATE ... 'delayed'` (`:135-138`) também é ignorado.
**Correção:** o item novo passa a levar `evidence_json: { milestone_ids: [id] }`; no 23505 lê-se o item aberto do workspace, junta-se o id do marco a `evidence_json.milestone_ids` e atualizam-se `title`/`description` para "Milestones em atraso (N)" (outros erros são registados com `log.warn`); o `fetch` ganha `AbortSignal.timeout(10_000)`; o erro do `UPDATE` é registado. O fallback do URL da aplicação passa a `PUBLIC_APP_URL || APP_URL || https://fb.startupleiria.com`.
**Alterar `supabase/functions/check-missed-milestones/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/check-missed-milestones/index.ts
+++ b/supabase/functions/check-missed-milestones/index.ts
@@ -30,4 +30,5 @@ async function sendTeamsNotification(
         payload,
       }),
+      signal: AbortSignal.timeout(10_000), // um teams-notify pendurado não pode bloquear o cron inteiro
     });
     if (!response.ok) {
@@ -133,8 +134,9 @@ Deno.serve(withCronRunLogging('check-missed-milestones', async (req) => {
 
       // Mark milestone as delayed
-      await supabase
+      const { error: delayErr } = await supabase
         .from('milestones')
         .update({ status: 'delayed' })
         .eq('id', milestone.id);
+      if (delayErr) log.error('Error marking milestone delayed', delayErr, { milestoneId: milestone.id });
 
       // Create workspace alert
@@ -149,4 +151,5 @@ Deno.serve(withCronRunLogging('check-missed-milestones', async (req) => {
           status: 'open',
           related_milestone_id: milestone.id,
+          evidence_json: { milestone_ids: [milestone.id] },
         })
         .select()
@@ -155,8 +158,34 @@ Deno.serve(withCronRunLogging('check-missed-milestones', async (req) => {
       if (!alertError && alertData) {
         createdAlerts.push(alertData.id);
+      } else if (alertError?.code === '23505') {
+        // idx_work_queue_unique_active: só 1 item aberto 'milestone_missed' por workspace.
+        // Em vez de perder o 2.º milestone em atraso, acrescenta-o à evidência do item aberto.
+        const { data: openItem } = await supabase
+          .from('staff_work_queue_items')
+          .select('id, evidence_json')
+          .eq('workspace_id', milestone.workspace_id)
+          .eq('type', 'milestone_missed')
+          .in('status', ['open', 'in_progress'])
+          .limit(1)
+          .maybeSingle();
+        if (openItem) {
+          const evidence = (openItem.evidence_json ?? {}) as { milestone_ids?: string[] };
+          const ids = Array.from(new Set([...(evidence.milestone_ids ?? []), milestone.id]));
+          const { error: mergeErr } = await supabase
+            .from('staff_work_queue_items')
+            .update({
+              title: `Milestones em atraso (${Math.max(ids.length, 2)})`,
+              description: `Há ${Math.max(ids.length, 2)} milestones com a data-alvo ultrapassada neste workspace.`,
+              evidence_json: { ...evidence, milestone_ids: ids },
+            })
+            .eq('id', openItem.id);
+          if (mergeErr) log.warn('work_queue_merge_failed', { milestoneId: milestone.id, error: mergeErr.message });
+        }
+      } else if (alertError) {
+        log.warn('work_queue_insert_failed', { milestoneId: milestone.id, error: alertError.message });
       }
 
       // Send Teams notification for action overdue
-      const appUrl = Deno.env.get('APP_URL') || 'https://startupleiria.app';
+      const appUrl = Deno.env.get('PUBLIC_APP_URL') || Deno.env.get('APP_URL') || 'https://fb.startupleiria.com';
       const teamsSent = await sendTeamsNotification(
         supabaseUrl,
```



## createLogger.error perde o contexto em 13 chamadores (ids: HRD-10, ED4-11, ED1-11)
**Gravidade:** LOW. **Quem é afetado:** quem diagnostica incidentes (admin, equipa técnica).
**Problema:** `_shared/security.ts:66-70` define `error(msg, error?, data?)` e faz `String(error)` quando o 2.º argumento não é um `Error`. Treze chamadores passam o contexto como 2.º argumento (`{ status, errText }`, `{ error: msg }`, erros do PostgREST): `analyze-contract/index.ts:176,222`, `analyze-contract-document/index.ts:54,172,209`, `check-consultant-availability/index.ts:248,285`, `validate-booking-slot/index.ts:197`, `send-message-email-alert/index.ts:174`, `sweep-session-transcripts/index.ts:194`, `transcribe-audio/index.ts:100`, `staff-assign-workspace-to-contract/index.ts:223`, `send-announcement-email/index.ts:247`. O log sai com `errMsg:"[object Object]"` e perde-se o estado HTTP e o texto de erro do gateway de IA. `log.error('x')` sem erro também gravava `errMsg:"undefined"`.
**Correção:** (diff em `security.ts`, na primeira secção deste domínio) um objeto simples (não `Error`, não array) passa a ser espalhado no JSON do log e `errMsg` fica com `message` se for texto, ou `see fields`; `Error` mantém `errMsg`/`errName`; `undefined`/`null` já não geram `errMsg`; `level` e `msg` ficam sempre por último para um objeto de contexto não os poder sobrescrever. Não é preciso mexer nos chamadores (em `send-message-email-alert` passámos `err` em vez de `{ err: String(err) }`). Cuidado habitual: não passe segredos como contexto. As partes de `analyze-contract` do achado ED1-11 (limite de pedidos de IA, UUID, timeout, `JSON.parse` dentro de `try`) estão na secção do domínio dono desse ficheiro.

---

## send-session-invite recusa o lote inteiro por um destinatário (ids: HRD-13)
**Gravidade:** LOW. **Quem é afetado:** consultor, founder (quem cria ou reagenda sessões).
**Problema:** `selectSessionRecipients` (`_shared/sessionRecipients.ts:4-15`) lança `recipient_not_authorized` (403) se QUALQUER endereço pedido estiver fora do conjunto registado. O cliente envia os emails de todos os membros do workspace (`CreateSessionDialog.tsx:469-480`); o servidor só considera perfis `approved` e membros ativos (`:34`). Um único membro pendente ou inativo faz perder o convite de todos, e o cliente só faz `logger.error` e mostra "sessão criada".
**Correção:** nova `intersectSessionRecipients(requested, allowed)` que devolve `{ recipients, skipped }` (o que está fora do conjunto é descartado e contado; lista malformada continua a lançar `invalid_recipients`). `send-session-invite/index.ts` usa-a: só devolve 403 se não sobrar nenhum destinatário e houve descartados; a resposta ganha `skipped`. `selectSessionRecipients` continua exportada (usada por `send-session-followup`, `send-survey-invites` e pelos testes). O cliente (`CreateSessionDialog.tsx`) continua a não mostrar o erro: cabe ao domínio do front-end.
**Alterar `supabase/functions/_shared/sessionRecipients.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/_shared/sessionRecipients.ts
+++ b/supabase/functions/_shared/sessionRecipients.ts
@@ -15,4 +15,21 @@ export function selectSessionRecipients(requested: unknown, allowed: string[]):
 }
 
+/**
+ * Like selectSessionRecipients, but addresses outside the server-recorded set are
+ * dropped (and counted) instead of rejecting the whole batch. A malformed list still throws.
+ */
+export function intersectSessionRecipients(requested: unknown, allowed: string[]): { recipients: string[]; skipped: number } {
+  const normalize = (value: string) => value.trim().toLowerCase();
+  const known = new Set(allowed.map(normalize).filter(Boolean));
+  if (requested == null) return { recipients: [...known], skipped: 0 };
+  if (!Array.isArray(requested) || requested.length > 50 || requested.some(value =>
+    typeof value !== 'string' || value.length > 255 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim()))) {
+    throw new Error('invalid_recipients');
+  }
+  const unique = [...new Set(requested.map(normalize))];
+  const recipients = unique.filter(email => known.has(email));
+  return { recipients, skipped: unique.length - recipients.length };
+}
+
 export async function getSessionRecipientEmails(admin: SupabaseClient, sessionId: string, workspaceId: string): Promise<string[]> {
   const [members, participants, session, workspace] = await Promise.all([
```

**Alterar `supabase/functions/send-session-invite/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/send-session-invite/index.ts
+++ b/supabase/functions/send-session-invite/index.ts
@@ -3,5 +3,5 @@ import { Resend } from "npm:resend@4.0.0";
 import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
 import { isAccountActive } from '../_shared/security.ts';
-import { getSessionRecipientEmails, selectSessionRecipients } from '../_shared/sessionRecipients.ts';
+import { getSessionRecipientEmails, intersectSessionRecipients } from '../_shared/sessionRecipients.ts';
 
 const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
@@ -249,7 +249,11 @@ serve(async (req) => {
     }
     
+    let skippedRecipients = 0;
     try {
-      payload.recipientEmails = selectSessionRecipients(payload.recipientEmails,
+      const selected = intersectSessionRecipients(payload.recipientEmails,
         await getSessionRecipientEmails(supabaseService, payload.sessionId, payload.workspaceId));
+      if (selected.recipients.length === 0 && selected.skipped > 0) throw new Error('recipient_not_authorized');
+      payload.recipientEmails = selected.recipients;
+      skippedRecipients = selected.skipped;
     } catch (error) {
       const lookupFailed = error instanceof Error && error.message === 'recipient_lookup_failed';
@@ -447,4 +451,5 @@ serve(async (req) => {
       JSON.stringify({ 
         message: `Sent ${successCount} invites`,
+        skipped: skippedRecipients,
         results 
       }),
```

---

## Emails de intake: assunto com escape HTML e `email_log.recipients` gravado como texto (ids: CRM-06)
**Gravidade:** LOW. **Quem é afetado:** anónimo (lead que recebe o email), staff.
**Problema:** `supabase/functions/send-intake-email/index.ts:143` reutiliza `safeOrg` (já com escape HTML) no assunto: `Silva & Filhos, Lda` chega como `Silva &amp; Filhos, Lda`. `send-intake-email/index.ts:267` e `send-commercial-proposal/index.ts:517` gravam `recipients: JSON.stringify([...])` numa coluna `jsonb`, ou seja uma string em vez de um array (as outras funções gravam arrays), o que parte `jsonb_array_elements`.
**Correção:** o assunto usa o nome sem escape (só com as quebras de linha removidas; `safeOrg` continua no HTML) e `recipients` passa a array. Fazer deploy das duas funções.
**Alterar `supabase/functions/send-intake-email/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/send-intake-email/index.ts
+++ b/supabase/functions/send-intake-email/index.ts
@@ -141,5 +141,6 @@ Deno.serve(async (req) => {
 
     if (type === 'intake_request') {
-      subject = `${safeOrg ? safeOrg + ' — ' : ''}Pedido de Contratação — Startup Leiria`
+      // O assunto é texto simples: sem escape HTML (senão 'Silva & Filhos' chega como 'Silva &amp; Filhos')
+      subject = `${organizationName ? String(organizationName).replace(/[\r\n]+/g, ' ') + ' — ' : ''}Pedido de Contratação — Startup Leiria`
       html = `
         <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px">
@@ -265,5 +266,5 @@ Deno.serve(async (req) => {
           email_type: `intake_${type}`,
           subject,
-          recipients: JSON.stringify([recipientEmail]),
+          recipients: [recipientEmail],
           status: 'sent',
           sent_at: new Date().toISOString(),
```

**Alterar `supabase/functions/send-commercial-proposal/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/send-commercial-proposal/index.ts
+++ b/supabase/functions/send-commercial-proposal/index.ts
@@ -515,5 +515,5 @@ Deno.serve(async (req) => {
         email_type: 'commercial_proposal',
         subject: body.subject,
-        recipients: JSON.stringify([item.contact_email]),
+        recipients: [item.contact_email],
         status: 'sent',
         sent_at: nowIso,
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## send-notification-email: o nome do documento vai sempre "documento" (ids: SCH-10)
**Gravidade:** LOW. **Quem é afetado:** consultor e founder (emails de revisão de documento).
**Problema:** `send-notification-email/index.ts:364-365` faz `select('title, name')` em `documents`, que não tem `title`: o erro 42703 deixa `data = null` e `docName` fica `documento` no assunto, corpo e Slack de `document_review_requested`/`document_review_approved`.
**Correção:** `select('name')` com `.eq('workspace_id', workspaceId)` (um `document_id` de outro workspace não pode aparecer no email) e `maybeSingle()`; sem `workspaceId` não se consulta (falha fechada, mantém `documento`).
**Alterar `supabase/functions/send-notification-email/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/send-notification-email/index.ts
+++ b/supabase/functions/send-notification-email/index.ts
@@ -361,7 +361,7 @@ async function handle(supabase: any, log: any, body: NotificationRequest): Promi
   if (type === 'document_review_requested' || type === 'document_review_approved') {
     let docName = 'documento';
-    if (body.document_id) {
-      const { data } = await supabase.from('documents').select('title, name').eq('id', body.document_id).single();
-      docName = (data as any)?.title ?? (data as any)?.name ?? docName;
+    if (body.document_id && workspaceId) {
+      const { data } = await supabase.from('documents').select('name').eq('id', body.document_id).eq('workspace_id', workspaceId).maybeSingle();
+      docName = (data as any)?.name ?? docName;
     }
     if (type === 'document_review_requested') {
```



## generate-first-contact-brief: colunas inexistentes (ids: SCH-11)
**Gravidade:** LOW. **Quem é afetado:** consultor e admin (hoje a função não tem chamador na UI, por isso o impacto atual é nulo).
**Problema:** o select de `funnel_items` (`generate-first-contact-brief/index.ts:135`) pede `phone` (a coluna é `contact_phone`): a função responde sempre 404 `not_found`. O select de `communication_log` (`:146`) pede `kind` e `summary` (as colunas são `activity_type` e `preview`).
**Correção:** `contact_phone` nas linhas 43, 135 e 169 e `activity_type, direction, subject, preview, occurred_at, original_timestamp` na 146. O diff está na primeira secção deste domínio (ficheiro único, ver acima).

---

## sync-graph-email-history falha em todas as mensagens fora do dry-run (ids: SCH-13, DBP-03)
**Gravidade:** LOW. **Quem é afetado:** staff (importação do histórico de email do Graph; hoje a UI só usa `dry_run:true`, por isso o estrago é latente).
**Problema:** `sync-graph-email-history/index.ts:331-351` faz `.upsert(..., { onConflict: 'external_source,external_id', ignoreDuplicates: true })` e os índices únicos sobre esse par são parciais: 42P10 em todas as mensagens, `result.errors` enche-se de `Insert error` e nada é gravado. A migração do domínio SQL (`rc12_conflict_targets`) recria o índice completo, o que já basta.
**Correção:** `.insert({...})` sem `onConflict`; duplicados caem no ramo `23505` → `skipped` que já existe. Assim a função funciona com ou sem a migração, independentemente da ordem de aplicação (testámos na base: o segundo `INSERT` do mesmo `ms_graph/external_id` dá 23505 `idx_communication_log_external_dedupe`).
**Alterar `supabase/functions/sync-graph-email-history/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/sync-graph-email-history/index.ts
+++ b/supabase/functions/sync-graph-email-history/index.ts
@@ -327,8 +327,9 @@ Deno.serve(async (req) => {
           }
 
-          // Upsert into communication_log
+          // Insert into communication_log (the unique indexes on external_source/external_id are
+          // partial, so ON CONFLICT cannot be inferred: duplicates come back as 23505 -> skipped)
           const { error } = await supabase
             .from('communication_log')
-            .upsert({
+            .insert({
               workspace_id: workspace_id || null,
               funnel_item_id: funnel_item_id || null,
@@ -347,7 +348,4 @@ Deno.serve(async (req) => {
                 cc: msg.ccRecipients?.map((r: any) => r.emailAddress?.address),
               },
-            }, {
-              onConflict: 'external_source,external_id',
-              ignoreDuplicates: true,
             });
```

---

## run-workflow-rules: tarefas de staff sem assignee_id (ids: SCH-14)
**Gravidade:** LOW. **Quem é afetado:** consultor, admin (a função está dormente: `docs/rc5/dead-edge-functions.md`).
**Problema:** a ação `create_staff_task` (`run-workflow-rules/index.ts:185-194`) insere em `staff_tasks` sem `assignee_id`, que é `NOT NULL` sem default: 23502 em todas as tarefas, e o erro só vai para `actionResult.error`.
**Correção:** o select de workspaces ganha `assigned_consultor_id` (e a interface `Workspace`); a tarefa é atribuída a esse consultor, e sem consultor atribuído a ação devolve `{ executed: false, error: 'workspace_has_no_assigned_consultor' }`.
**Alterar `supabase/functions/run-workflow-rules/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/run-workflow-rules/index.ts
+++ b/supabase/functions/run-workflow-rules/index.ts
@@ -21,4 +21,5 @@ interface Workspace {
   health_status: string | null;
   status: string;
+  assigned_consultor_id: string | null;
 }
 
@@ -58,5 +59,5 @@ Deno.serve(async (req: Request) => {
     const { data: workspaces, error: wsError } = await supabase
       .from('workspaces')
-      .select('id, program_id, health_status, status')
+      .select('id, program_id, health_status, status, assigned_consultor_id')
       .eq('status', 'active');
 
@@ -183,8 +184,14 @@ Deno.serve(async (req: Request) => {
           switch (actionType) {
             case 'create_staff_task': {
+              // staff_tasks.assignee_id is NOT NULL: the task goes to the workspace's assigned consultant.
+              if (!workspace.assigned_consultor_id) {
+                actionResult = { executed: false, error: 'workspace_has_no_assigned_consultor' };
+                break;
+              }
               const { data: task, error: taskError } = await supabase
                 .from('staff_tasks')
                 .insert({
                   workspace_id: workspace.id,
+                  assignee_id: workspace.assigned_consultor_id,
                   title: `[Auto] ${rule.actions_json.task_template || 'Follow-up required'}`,
                   description: `Triggered by workflow rule: ${rule.trigger_type}. Context: ${JSON.stringify(actionContext)}`,
```

---

## run-ecosystem-snapshot: paginação sem ORDER BY (ids: OPS-11)
**Gravidade:** LOW. **Quem é afetado:** admin (exportação diária do ecossistema).
**Problema:** `run-ecosystem-snapshot/index.ts:121-124` lê cada tabela em páginas de 1000 com `.range()` sem ordenar; com escritas concorrentes o Postgres pode repetir ou saltar linhas entre páginas, e a contagem e o checksum do manifesto "validam" um ficheiro incompleto. (Os snapshots nunca são apagados e só cobrem 10 tabelas: a retenção e a cobertura são decisões de produto, ver PITR; não alteradas aqui.)
**Correção:** `.order('id', { ascending: true })` antes de `.range(from, to)` (as 10 fontes têm coluna `id`).
**Alterar `supabase/functions/run-ecosystem-snapshot/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/run-ecosystem-snapshot/index.ts
+++ b/supabase/functions/run-ecosystem-snapshot/index.ts
@@ -122,4 +122,5 @@ Deno.serve(withCronRunLogging('run-ecosystem-snapshot', async (req) => {
           .from(domain.table)
           .select('*')
+          .order('id', { ascending: true })
           .range(from, to);
```

---

## Fallbacks de URL da aplicação inconsistentes (ids: SCH-17)
**Gravidade:** LOW. **Quem é afetado:** founder, consultor e admin (links em notificações e emails de digest/anúncio).
**Problema:** 16 funções usam `PUBLIC_APP_URL || 'https://fb.startupleiria.com'`, mas `recompute-health-scores/index.ts:21`, `calendar-feed/index.ts:201`, `check-missed-milestones/index.ts:160` e `sync-outlook-calendar/index.ts:467` usam `APP_URL || 'https://startupleiria.app'`, e `send-email-digest/index.ts:8` e `send-announcement-email/index.ts:8` usam `SITE_URL || 'https://startupleiria.com'`. Se `APP_URL`/`SITE_URL` não estiverem definidas em produção, os links apontam para outro domínio.
**Correção:** os quatro primeiros passam a `PUBLIC_APP_URL || APP_URL || 'https://fb.startupleiria.com'` e os dois digests a `PUBLIC_APP_URL || SITE_URL || 'https://fb.startupleiria.com'`. Confirme que `fb.startupleiria.com` é o domínio canónico; se não for, use o correto nos 6 sítios. Os diffs de `calendar-feed`, `check-missed-milestones` e `sync-outlook-calendar` estão nas secções acima.
**Alterar `supabase/functions/recompute-health-scores/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/recompute-health-scores/index.ts
+++ b/supabase/functions/recompute-health-scores/index.ts
@@ -19,5 +19,5 @@ async function sendTeamsHealthAlert(
 ) {
   try {
-    const appUrl = Deno.env.get('APP_URL') || 'https://startupleiria.app';
+    const appUrl = Deno.env.get('PUBLIC_APP_URL') || Deno.env.get('APP_URL') || 'https://fb.startupleiria.com';
     const response = await fetch(`${supabaseUrl}/functions/v1/teams-notify`, {
       method: 'POST',
```

**Alterar `supabase/functions/send-email-digest/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/send-email-digest/index.ts
+++ b/supabase/functions/send-email-digest/index.ts
@@ -6,5 +6,5 @@ import { withCronRunLogging } from '../_shared/cronRun.ts';
 const FUNCTION_NAME = 'send-email-digest';
 const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
-const SITE_URL = Deno.env.get("SITE_URL") || "https://startupleiria.com";
+const SITE_URL = Deno.env.get("PUBLIC_APP_URL") || Deno.env.get("SITE_URL") || "https://fb.startupleiria.com";
 
 type Locale = 'pt' | 'en';
```

**Alterar `supabase/functions/send-announcement-email/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/send-announcement-email/index.ts
+++ b/supabase/functions/send-announcement-email/index.ts
@@ -6,5 +6,5 @@ import { resolveLocalesByEmails, type Locale } from '../_shared/i18n.ts';
 const FUNCTION_NAME = 'send-announcement-email';
 const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
-const SITE_URL = Deno.env.get("SITE_URL") || "https://startupleiria.com";
+const SITE_URL = Deno.env.get("PUBLIC_APP_URL") || Deno.env.get("SITE_URL") || "https://fb.startupleiria.com";
 
 interface AnnouncementRequest { announcement_ids: string[]; }
```

---

## copilot-apply-playbook: o preflight não reflete o RLS e reaplicar o playbook devolve 500 (id: ED1-09)
**Gravidade:** LOW. **Quem é afetado:** team_member e backoffice (recebem 500 com texto de RLS); qualquer papel ao reaplicar o mesmo playbook.
**Problema:** o preflight de `copilot-apply-playbook/index.ts:43-64` aceita qualquer membro ativo e qualquer staff (incluindo backoffice), mas o RLS de `milestones`/`action_items` exige `can_write_workspace`, falso para team_member e backoffice: recebem 500 com `new row violates row-level security policy for table "milestones"`. Aplicar o mesmo playbook duas vezes cria um milestone, falha as ações com 23505 (`action_items_workspace_source_deliverable_uniq`), apaga o milestone e devolve 500 com o nome da constraint no toast (`:120-125`). `due_offset_days` enorme ou negativo gera Date inválida (`:29`), `playbook_key` `__proto__`/`constructor` passa o `if (!playbook)` (`:38`) e o erro do rollback do milestone é ignorado.
**Correção:** `workspace_id` validado como UUID; `due_offset_days` inteiro entre 0 e 365 (senão 14); `hasOwnProperty` no catálogo (404); preflight com `rpc('can_write_workspace')` (o mesmo predicado do RLS: 403 em PT-PT se for falso, 500 `Could not verify workspace access` se a RPC falhar); pré-verificação por `source_deliverable_key` (`playbook:<chave>:%`) com 409 `ALREADY_APPLIED`; 42501 passa a 403 e 23505 a 409; o erro do DELETE de rollback é registado; mensagens genéricas em vez de `aiErr.message`/`e.message`. Nota: `invokeWithAuth` mostra "403: Access denied (copilot-apply-playbook)" para 403 (texto genérico já existente) e a mensagem em PT-PT para o 409.
**Alterar `supabase/functions/copilot-apply-playbook/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/copilot-apply-playbook/index.ts
+++ b/supabase/functions/copilot-apply-playbook/index.ts
@@ -4,4 +4,6 @@ import { handleCorsOptions, corsJsonResponse } from "../_shared/cors.ts";
 import { PLAYBOOK_CATALOG, type PlaybookKey } from "../_shared/playbook-catalog.ts";
 
+const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
+
 serve(async (req: Request) => {
   if (req.method === "OPTIONS") return handleCorsOptions(req);
@@ -27,39 +29,43 @@ serve(async (req: Request) => {
     const playbookKey = body.playbook_key as PlaybookKey;
     const workspaceId = body.workspace_id as string;
-    const dueOffsetDays = Number.isFinite(body.due_offset_days) ? body.due_offset_days : 14;
+    const dueOffsetDays = Number.isInteger(body.due_offset_days) && body.due_offset_days >= 0 && body.due_offset_days <= 365
+      ? body.due_offset_days
+      : 14;
 
     if (!playbookKey || typeof playbookKey !== "string") {
       return corsJsonResponse({ error: "playbook_key is required" }, req, 400);
     }
-    if (!workspaceId || typeof workspaceId !== "string") {
-      return corsJsonResponse({ error: "workspace_id is required" }, req, 400);
+    if (!workspaceId || typeof workspaceId !== "string" || !UUID_RE.test(workspaceId)) {
+      return corsJsonResponse({ error: "workspace_id must be a UUID" }, req, 400);
     }
 
+    if (!Object.prototype.hasOwnProperty.call(PLAYBOOK_CATALOG, playbookKey)) {
+      return corsJsonResponse({ error: "Unknown playbook" }, req, 404);
+    }
     const playbook = PLAYBOOK_CATALOG[playbookKey];
-    if (!playbook) {
-      return corsJsonResponse({ error: `Unknown playbook: ${playbookKey}` }, req, 404);
+
+    // Pré-verificação com o MESMO predicado do RLS de milestones/action_items (can_write_workspace):
+    // evita o 500 com mensagem de RLS para team_member/backoffice (membros ou staff sem escrita).
+    const { data: canWrite, error: canWriteErr } = await supabase.rpc("can_write_workspace", {
+      _workspace_id: workspaceId,
+    });
+    if (canWriteErr) {
+      console.error("can_write_workspace failed:", canWriteErr.message);
+      return corsJsonResponse({ error: "Could not verify workspace access" }, req, 500);
+    }
+    if (canWrite !== true) {
+      return corsJsonResponse({ error: "Sem permissão de escrita neste workspace." }, req, 403);
     }
 
-    // RLS will gate writes via can_write_workspace; do a friendly preflight.
-    const { data: access } = await supabase
-      .from("workspace_users")
-      .select("workspace_id, role")
-      .eq("user_id", user.id)
+    // Idempotência: o mesmo playbook não se aplica duas vezes ao mesmo workspace
+    // (índice único action_items_workspace_source_deliverable_uniq).
+    const { data: alreadyApplied } = await supabase
+      .from("action_items")
+      .select("id")
       .eq("workspace_id", workspaceId)
-      .eq("active", true)
-      .maybeSingle();
-
-    // Staff (admin/consultor/backoffice) can write all workspaces via RLS; only block clear non-members
-    if (!access) {
-      const { data: roles } = await supabase
-        .from("user_roles")
-        .select("role")
-        .eq("user_id", user.id);
-      const isStaff = (roles || []).some((r: any) =>
-        ["admin", "consultor", "backoffice"].includes(r.role)
-      );
-      if (!isStaff) {
-        return corsJsonResponse({ error: "No access to this workspace" }, req, 403);
-      }
+      .like("source_deliverable_key", `playbook:${playbookKey}:%`)
+      .limit(1);
+    if (alreadyApplied && alreadyApplied.length > 0) {
+      return corsJsonResponse({ error: "Este playbook já foi aplicado a este workspace.", code: "ALREADY_APPLIED" }, req, 409);
     }
 
@@ -87,8 +93,9 @@ serve(async (req: Request) => {
     if (msErr || !milestone) {
       console.error("milestone insert failed:", msErr?.message);
+      const denied = msErr?.code === "42501";
       return corsJsonResponse(
-        { error: msErr?.message || "Could not create milestone" },
+        { error: denied ? "Sem permissão de escrita neste workspace." : "Could not create milestone" },
         req,
-        500
+        denied ? 403 : 500
       );
     }
@@ -121,6 +128,10 @@ serve(async (req: Request) => {
       console.error("action_items insert failed:", aiErr.message);
       // Roll back milestone to avoid orphan
-      await supabase.from("milestones").delete().eq("id", milestone.id);
-      return corsJsonResponse({ error: aiErr.message }, req, 500);
+      const { error: rollbackErr } = await supabase.from("milestones").delete().eq("id", milestone.id);
+      if (rollbackErr) console.error("milestone rollback failed:", milestone.id, rollbackErr.message);
+      if (aiErr.code === "23505") {
+        return corsJsonResponse({ error: "Este playbook já foi aplicado a este workspace.", code: "ALREADY_APPLIED" }, req, 409);
+      }
+      return corsJsonResponse({ error: "Could not create playbook actions" }, req, 500);
     }
 
@@ -137,5 +148,5 @@ serve(async (req: Request) => {
   } catch (e: any) {
     console.error("copilot-apply-playbook error:", e?.message);
-    return corsJsonResponse({ error: e?.message || "Internal error" }, req, 500);
+    return corsJsonResponse({ error: "Internal error" }, req, 500);
   }
 });
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## export-cohort-health-pdf: histórico truncado a 1000 linhas e erros de consulta ignorados (id: ED2-09)
**Gravidade:** LOW. **Quem é afetado:** admin, consultor, backoffice (a função não tem chamador em `src/` hoje).
**Problema:** `export-cohort-health-pdf/index.ts:98-129` consulta `workspace_health_history` sem paginar: há 1 snapshot por workspace por dia, por isso 34 workspaces em 30 dias já passam de 1000 linhas e o PostgREST corta os dias mais recentes (ordem ascendente), dando "Pontuação Final" e variações erradas sem aviso. Os erros das consultas de workspaces e histórico são ignorados (relatório vazio como se fosse verdade), o papel só aceita admin/consultor (backoffice excluído, ao contrário do cliente), não há `isAccountActive` e datas inválidas dão 500 com a mensagem interna (`:332-335`).
**Correção:** histórico lido por páginas de 1000 (`order computed_at, id` + `range`), erros de workspaces/histórico lançados, backoffice aceite, `isAccountActive` (403), `program_id` validado como UUID (400), intervalo de datas inválido ou invertido (400) e 500 genérico `Internal server error`.
**Alterar `supabase/functions/export-cohort-health-pdf/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/export-cohort-health-pdf/index.ts
+++ b/supabase/functions/export-cohort-health-pdf/index.ts
@@ -4,4 +4,6 @@ import { getCorsHeaders, handleCorsOptions, corsJsonResponse } from '../_shared/
 import { normalizeLocale, pickLang, type Locale } from '../_shared/i18n.ts';
 import { escapeHtml, REPORT_CSP_META } from '../_shared/html.ts';
+import { isAccountActive } from '../_shared/security.ts';
+import { validateUUID } from '../_shared/validation.ts';
 
 const T = {
@@ -70,15 +72,24 @@ serve(async (req) => {
       .eq("user_id", user.id);
 
-    const isStaff = roles?.some(r => r.role === "admin" || r.role === "consultor");
+    const isStaff = roles?.some(r => r.role === "admin" || r.role === "consultor" || r.role === "backoffice");
     if (!isStaff) {
       return corsJsonResponse({ error: "Forbidden" }, req, 403);
     }
+    if (!(await isAccountActive(supabase, user.id))) {
+      return corsJsonResponse({ error: "Forbidden" }, req, 403);
+    }
 
-    const body: ExportRequest = await req.json();
-    const { program_id, start_date, end_date } = body;
+    const body: ExportRequest = await req.json().catch(() => ({} as ExportRequest));
+    const programCheck = validateUUID(body?.program_id, 'program_id');
+    if (!programCheck.valid) return corsJsonResponse({ error: programCheck.error }, req, 400);
+    const program_id = programCheck.value!;
+    const { start_date, end_date } = body;
 
     const now = new Date();
     const startDate = start_date ? new Date(start_date) : new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
     const endDate = end_date ? new Date(end_date) : now;
+    if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime()) || startDate > endDate) {
+      return corsJsonResponse({ error: "Invalid date range" }, req, 400);
+    }
 
     console.log(`Exporting cohort health for program: ${program_id}`);
@@ -96,5 +107,5 @@ serve(async (req) => {
 
     // Get workspaces for this program
-    const { data: workspacesRaw } = await supabase
+    const { data: workspacesRaw, error: workspacesError } = await supabase
       .from("workspaces")
       .select(`
@@ -109,4 +120,6 @@ serve(async (req) => {
       .order("health_score_numeric", { ascending: true });
 
+    if (workspacesError) throw workspacesError;
+
     // Helper to get startup name (supabase returns joined data as array)
     const getStartupName = (ws: any): string => {
@@ -121,11 +134,24 @@ serve(async (req) => {
 
     // Get health history for the period
-    const { data: historyData } = await supabase
-      .from("workspace_health_history")
-      .select("workspace_id, score_numeric, label, computed_at")
-      .in("workspace_id", workspaceIds)
-      .gte("computed_at", startDate.toISOString())
-      .lte("computed_at", endDate.toISOString())
-      .order("computed_at", { ascending: true });
+    // PostgREST devolve no máximo 1000 linhas por pedido (1 snapshot por workspace por dia):
+    // paginar, senão os últimos dias do período desaparecem e a variação sai errada.
+    const historyData: Array<{ workspace_id: string; score_numeric: number; label: string; computed_at: string }> = [];
+    if (workspaceIds.length > 0) {
+      const PAGE = 1000;
+      for (let from = 0; ; from += PAGE) {
+        const { data: page, error: historyError } = await supabase
+          .from("workspace_health_history")
+          .select("workspace_id, score_numeric, label, computed_at")
+          .in("workspace_id", workspaceIds)
+          .gte("computed_at", startDate.toISOString())
+          .lte("computed_at", endDate.toISOString())
+          .order("computed_at", { ascending: true })
+          .order("id", { ascending: true })
+          .range(from, from + PAGE - 1);
+        if (historyError) throw historyError;
+        historyData.push(...(page ?? []));
+        if (!page || page.length < PAGE) break;
+      }
+    }
 
     // Calculate distribution
@@ -332,6 +358,5 @@ serve(async (req) => {
   } catch (error: unknown) {
     console.error("Error in export-cohort-health-pdf:", error);
-    const message = error instanceof Error ? error.message : "Unknown error";
-    return corsJsonResponse({ error: message }, req, 500);
+    return corsJsonResponse({ error: "Internal server error" }, req, 500);
   }
 });
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## generate-financial-prefill pede colunas que não existem em workspaces (id: SCH-09)
**Gravidade:** LOW. **Quem é afetado:** founder (plano financeiro guiado, atrás de feature flag).
**Problema:** `generate-financial-prefill/index.ts:97-99` faz `select("id, name, stage, sector, program_type")` em `workspaces`, e nenhuma de `name`, `sector` e `program_type` existe: o erro é ignorado e `workspace` fica `null`. A fase vem só de `diagnostic.stage` (ou nada), por isso os valores por fase (headcount, salário, capex) caem quase sempre no escalão por defeito e o prompt de IA vai sem nome e sem setor (`:188`). As propostas ficam `pending` e o founder confirma, daí LOW.
**Correção:** `.select("id, stage, startup:startups(name)")` e `workspace: { name: (workspace?.startup as { name?: string } | null)?.name, stage, sector: diagnostic.sector }` no contexto enviado ao modelo.
**Alterar `supabase/functions/generate-financial-prefill/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/generate-financial-prefill/index.ts
+++ b/supabase/functions/generate-financial-prefill/index.ts
@@ -96,5 +96,5 @@ serve(async (req) => {
     ] = await Promise.all([
       supabase.from("workspaces")
-        .select("id, name, stage, sector, program_type")
+        .select("id, stage, startup:startups(name)")
         .eq("id", workspaceId).maybeSingle(),
       supabase.from("financial_plan_sessions")
@@ -186,5 +186,5 @@ serve(async (req) => {
       } else {
         const context = {
-          workspace: { name: workspace?.name, stage, sector: workspace?.sector ?? diagnostic.sector },
+          workspace: { name: (workspace?.startup as { name?: string } | null)?.name, stage, sector: diagnostic.sector },
           diagnostic,
           missing_keys: stillMissing,
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*

---

## dataroom-revoke-link: revogar de novo reescreve a data da revogação original (id: ED3-15)
**Gravidade:** LOW. **Quem é afetado:** founder, consultor, admin.
**Problema:** o UPDATE de `dataroom-revoke-link/index.ts:62-65` não restringe a links ainda ativos: se o utilizador clicar duas vezes (ou revogar um link já revogado), `revoked_at` passa a ser a data da última chamada, perdendo o momento real da revogação (auditoria do acesso de investidores).
**Correção:** acrescentar `.is('revoked_at', null)` ao UPDATE; a resposta continua `success: true` (idempotente).
**Alterar `supabase/functions/dataroom-revoke-link/index.ts`** (diff; os números de linha são do ficheiro original):

```diff
--- a/supabase/functions/dataroom-revoke-link/index.ts
+++ b/supabase/functions/dataroom-revoke-link/index.ts
@@ -63,5 +63,6 @@ Deno.serve(async (req: Request) => {
       .from('dataroom_share_links')
       .update({ revoked_at: new Date().toISOString() })
-      .eq('id', link_id);
+      .eq('id', link_id)
+      .is('revoked_at', null); // revogar de novo não reescreve a data da revogação original
 
     if (updateError) {
```

---

## Convite da sessão falha em silêncio no diálogo "Agendar sessão" (ids: HRD-13, parte cliente)
**Gravidade:** LOW. **Quem é afetado:** consultor e admin (quem cria sessões); founder e equipa (quem deixa de receber o convite sem ninguém saber).
**Problema:** `src/components/workspace/sessions/CreateSessionDialog.tsx:469-500` chama `send-session-invite`, só regista o erro com `logger.error` e mostra sempre "Sessão criada". Com a correção do servidor (secção HRD-13 do domínio das funções edge), a função devolve agora `skipped` (destinatários sem conta ativa, em vez de recusar o lote todo) e `results` (por email), mas o cliente continua a ignorá-los: os participantes que não receberam o convite não são avisados a ninguém.
**Correção:** novo ficheiro `sessionInviteOutcome.ts` com `getSessionInviteOutcome(resultado)`, que devolve `failed` (erro da chamada, ou todos os envios falharam), `partial` (soma de `skipped` com os envios falhados) ou `ok`. O diálogo mostra, depois de "Sessão criada", um aviso `notify.warn` (8 s) com o texto adequado; a exceção do `try` também gera o aviso de falha. A sessão continua a ser criada em qualquer dos casos. O teste `sessionInviteOutcome.test.ts` (8 casos) falha sem o ficheiro novo e passa com ele. Chaves novas de i18n (pt/en, juntar a `pt.json` e `en.json`): `sessions.createdInviteFailed` ("Sessão criada, mas não foi possível enviar os convites por email. Avise os participantes manualmente.") e `sessions.createdInvitePartial` ("Sessão criada, mas {{count}} destinatário(s) não receberam o convite por email (sem conta ativa ou envio falhado). Avise-os manualmente.").
**Alterar `src/components/workspace/sessions/CreateSessionDialog.tsx`** (diff; os números de linha são do ficheiro original):

```diff
--- a/src/components/workspace/sessions/CreateSessionDialog.tsx
+++ b/src/components/workspace/sessions/CreateSessionDialog.tsx
@@ -49,4 +49,5 @@ import { invokeWithAuth } from "@/lib/invokeWithAuth";
 import { useLocalFormDraft } from '@/hooks/useLocalFormDraft';
 import { DraftRestoredNotice } from '@/components/shared/DraftRestoredNotice';
+import { getSessionInviteOutcome } from './sessionInviteOutcome';
 
 interface CreateSessionDialogProps {
@@ -452,4 +453,6 @@ export function CreateSessionDialog({ workspaceId, open, onOpenChange }: CreateS
       });
 
+      // HRD-13: o convite por email não pode falhar em silêncio (a sessão já foi criada).
+      let inviteWarning: string | null = null;
       if (!logPast && sendInvites) {
 
@@ -478,5 +481,5 @@ export function CreateSessionDialog({ workspaceId, open, onOpenChange }: CreateS
 
           if (recipientEmails.length > 0) {
-            const { error } = await invokeWithAuth('send-session-invite', {
+            const inviteResult = await invokeWithAuth('send-session-invite', {
               body: {
                 sessionId: session.id,
@@ -494,10 +497,17 @@ export function CreateSessionDialog({ workspaceId, open, onOpenChange }: CreateS
             });
 
-            if (error) {
-              logger.error('Failed to send invites', {}, error);
+            if (inviteResult.error) {
+              logger.error('Failed to send invites', {}, inviteResult.error);
+            }
+            const inviteOutcome = getSessionInviteOutcome(inviteResult);
+            if (inviteOutcome.kind === 'failed') {
+              inviteWarning = t('sessions.createdInviteFailed', 'Sessão criada, mas não foi possível enviar os convites por email. Avise os participantes manualmente.');
+            } else if (inviteOutcome.kind === 'partial') {
+              inviteWarning = t('sessions.createdInvitePartial', 'Sessão criada, mas {{count}} destinatário(s) não receberam o convite por email (sem conta ativa ou envio falhado). Avise-os manualmente.', { count: inviteOutcome.notDelivered });
             }
           }
         } catch (emailError) {
           logger.error('Email sending error', {}, emailError);
+          inviteWarning = t('sessions.createdInviteFailed', 'Sessão criada, mas não foi possível enviar os convites por email. Avise os participantes manualmente.');
         }
       }
@@ -505,4 +515,5 @@ export function CreateSessionDialog({ workspaceId, open, onOpenChange }: CreateS
 
       notify.success(t('sessions.sessionCreated'));
+      if (inviteWarning) notify.warn(inviteWarning, { duration: 8000 });
       onOpenChange(false);
       resetForm();
```

**Criar `src/components/workspace/sessions/sessionInviteOutcome.ts`** (conteúdo exato):

```
/**
 * Traduz a resposta de `send-session-invite` no aviso que o CreateSessionDialog mostra (HRD-13).
 *
 * O servidor devolve `{ message, skipped, results: [{ email, success }] }`: `skipped` conta os
 * destinatários sem conta ativa (ignorados, já não recusam o lote) e `results` o envio por email.
 */
export type SessionInviteOutcome =
  | { kind: 'ok' }
  | { kind: 'failed' }
  | { kind: 'partial'; notDelivered: number };

export function getSessionInviteOutcome(
  result: { data?: unknown; error?: unknown } | null | undefined,
): SessionInviteOutcome {
  if (!result || result.error) return { kind: 'failed' };

  const data = (result.data ?? null) as { skipped?: unknown; results?: unknown } | null;
  const results = Array.isArray(data?.results) ? (data.results as Array<{ success?: unknown } | null>) : [];
  const failed = results.filter((r) => r?.success === false).length;
  if (results.length > 0 && failed === results.length) return { kind: 'failed' };

  const skippedRaw = Number(data?.skipped);
  const skipped = Number.isFinite(skippedRaw) && skippedRaw > 0 ? Math.floor(skippedRaw) : 0;
  const notDelivered = failed + skipped;
  return notDelivered > 0 ? { kind: 'partial', notDelivered } : { kind: 'ok' };
}
```

*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*
## Botão "Gerar update" visível a mentores que recebem 403 (ids: ED2-06, parte cliente)
**Gravidade:** LOW (o achado ED2-06, MED, está corrigido no servidor; isto é só a interface). **Quem é afetado:** mentor externo (com NDA).
**Problema:** depois da correção de `generate-investor-update` e de `dataroom-create-link` (ambas passam a exigir `canMutateWorkspace`, isto é, `can_write_workspace`), o mentor deixa de poder escrever. Mas `src/components/workspace/DataroomTab.tsx:243` mostra o bloco com os botões "Gerar update" e "Criar link" a quem tem `canWrite`, e `src/pages/WorkspaceDetail.tsx:92` calcula `canWrite = isAdmin || isConsultor || isMentor || (...)`, ou seja, dá `canWrite` também ao mentor (passa por `DocumentsTab.tsx:474` até ao `DataroomTab`): o mentor carrega no botão e recebe 403.
**Correção:** uma só linha, `DataroomTab.tsx:243`: `{canWrite && (` passa a `{canWrite && !isMentor && (`. `isMentor` já é prop do componente (linha 47) e está em scope. Não mexe em `canWrite` para não afetar os outros separadores. O diff completo de `DataroomTab.tsx` (que inclui esta linha e a troca de texto da secção FEF-07) aparece uma só vez, na secção FEF-07 do domínio do front-end do founder; por isso não se repete aqui o marcador.
*(Consultas de dados já afetados: ver `LOVABLE-RC12-DADOS-AFETADOS.sql`; são para o responsável correr, não para o Lovable.)*
